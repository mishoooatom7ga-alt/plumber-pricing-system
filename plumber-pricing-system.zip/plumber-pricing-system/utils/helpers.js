const fs = require('fs');
const path = require('path');

exports.readJSON = filePath => {
    try {
        const rawData = fs.readFileSync(filePath, "utf8");
        return JSON.parse(rawData);
    } catch (error) {
        console.error(`Error reading or parsing JSON file at ${filePath}:`, error);
        if (error.code === 'ENOENT') {
            // If file not found is expected sometimes (like initial run)
            // return []; // or {} depending on structure
            throw new Error(`File not found: ${filePath}`);
        }
        throw new Error(`Failed to read or parse JSON file: ${filePath}`);
    }
};

exports.writeJSON = (filePath, data) => {
    try {
         const dirname = path.dirname(filePath);
         if (!fs.existsSync(dirname)) {
             fs.mkdirSync(dirname, { recursive: true });
         }
         // Use asynchronous write for better performance, although sync is simpler here
         fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
         console.error(`Error writing JSON file to ${filePath}:`, error);
         throw new Error(`Failed to write JSON file: ${filePath}`);
    }
};