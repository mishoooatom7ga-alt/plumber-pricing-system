// utils/alertMailer.js
// إرسال تنبيهات البريد الإلكتروني عند حدوث خطأ في السيرفر

const nodemailer = require("nodemailer");
require("dotenv").config();
const path = require("path");

const { ALERT_EMAIL_USER, ALERT_EMAIL_PASS, ALERT_EMAIL_TO } = process.env;

if (!ALERT_EMAIL_USER || !ALERT_EMAIL_PASS || !ALERT_EMAIL_TO) {
  console.warn("⚠️ تنبيه: لم يتم ضبط إعدادات البريد في ملف .env");
}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: ALERT_EMAIL_USER,
    pass: ALERT_EMAIL_PASS,
  },
});

async function sendErrorAlert(subject, htmlMessage) {
  try {
    const info = await transporter.sendMail({
      from: `"Plumber Pricing System" <${ALERT_EMAIL_USER}>`,
      to: ALERT_EMAIL_TO,
      subject: subject || "🚨 تنبيه من Plumber Pricing System",
      html: htmlMessage || "<pre>حدث خطأ غير معروف في السيرفر</pre>",
    });

    console.log("📧 تم إرسال تنبيه البريد الإلكتروني بنجاح ✅", info.messageId);
  } catch (error) {
    console.error("❌ فشل إرسال البريد:", error.message);

    try {
      fs.appendFileSync(
        path.join(__dirname, "..", "logs", "errors.log"),
        `\n[${new Date().toLocaleString()}] فشل إرسال البريد: ${error.message}\n${error.stack}\n`
      );
    } catch (e) {
      console.error("⚠️ فشل تسجيل الخطأ في ملف السجلات:", e.message);
    }
  }
}

module.exports = { sendErrorAlert };
