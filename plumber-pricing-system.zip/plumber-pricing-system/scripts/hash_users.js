// scripts/hash_users.js
// Usage: node scripts/hash_users.js
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcryptjs');

const USERS_PATH = path.join(__dirname, '..', 'data', 'users.json');
const BACKUP_PATH = path.join(__dirname, '..', 'data', 'users.json.bak');
const SALT_ROUNDS = 10; // يمكنك تغييره عبر .env لاحقاً

async function main() {
  try {
    const raw = await fs.readFile(USERS_PATH, 'utf8');
    const users = JSON.parse(raw);

    // عمل نسخة احتياطية (مكتوبة فوق النسخة السابقة)
    await fs.writeFile(BACKUP_PATH, JSON.stringify(users, null, 2), 'utf8');
    console.log('Backup written to', BACKUP_PATH);

    let changed = false;
    for (let user of users) {
      // تخمين إذا كانت القيمة بالفعل هاش bcrypt (تبدأ بـ $2)
      const pwKey = Object.keys(user).find(k => /pass|password|pwd|passwd/i.test(k));
      if (!pwKey) continue;

      const val = user[pwKey] + '';
      if (!val.startsWith('$2')) { // إذا ليست hash
        const hash = await bcrypt.hash(val, SALT_ROUNDS);
        user[pwKey] = hash;
        changed = true;
        console.log(`Hashed password for user: ${user.username || '<no-username>'}`);
      } else {
        console.log(`Already hashed: ${user.username || '<no-username>'}`);
      }
    }

    if (changed) {
      await fs.writeFile(USERS_PATH, JSON.stringify(users, null, 2), 'utf8');
      console.log('Updated users.json with hashed passwords.');
    } else {
      console.log('No changes needed; all passwords seem hashed.');
    }
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

main();
