// server.js (كامل - مُحدث بنظام JWT و HttpOnly Cookies وإصلاح خطأ الزائر ومشكلة حماية login.html)

require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { GoogleSpreadsheet } = require("google-spreadsheet");
const { JWT } = require("google-auth-library");
const winston = require("winston");
const cron = require("node-cron");
const bcrypt = require("bcryptjs");
const axios = require("axios");
const FormData = require("form-data");
const puppeteer = require("puppeteer");
const jwt = require('jsonwebtoken');        // <<<--- (مطلوب لـ JWT)
const cookieParser = require('cookie-parser'); // <<<--- (مطلوب لـ JWT)

// دالة إرسال تنبيهات
const { sendErrorAlert } = require("./utils/alertMailer");
// دوال مساعدة JSON
const { readJSON, writeJSON } = require('./utils/helpers');

// ================================
// 🧩 تحميل الإعدادات من config.js
// ================================
const {
  PORT = 3000,
  SPREADSHEET_ID,
  CACHE_HOURS = 6,
  CACHE_DIR = path.join(__dirname, "cache"),
  CACHE_FILE = path.join(__dirname, "cache", "products.json"),
  GOOGLE_KEYFILE = path.join(__dirname, "google-credentials.json"),
  LOG_FILE = path.join(__dirname, "logs", "combined.log"),
  ERR_LOG_FILE = path.join(__dirname, "logs", "error.log"),
  TELEGRAM_BOT_TOKEN,
  TELEGRAM_CHAT_ID
} = (() => {
  try {
    return require("./config/config");
  } catch (e) {
    console.error("❌ فشل تحميل ملف config/config.js", e);
    // Provide default fallback values if config load fails
    return {
      PORT: 3000, CACHE_HOURS: 6, CACHE_DIR: path.join(__dirname, "cache"), CACHE_FILE: path.join(__dirname, "cache", "products.json"),
      GOOGLE_KEYFILE: path.join(__dirname, "google-credentials.json"), LOG_FILE: path.join(__dirname, "logs", "combined.log"), ERR_LOG_FILE: path.join(__dirname, "logs", "error.log"),
      TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID: process.env.TELEGRAM_CHAT_ID,
      JWT_SECRET: process.env.JWT_SECRET // (تأكد من وجوده)
    };
  }
})();

// (التحقق من المفتاح السري لـ JWT)
if (!process.env.JWT_SECRET) {
    console.error("❌ خطأ فادح: متغير البيئة JWT_SECRET غير معين. سيتم إيقاف التشغيل.");
    process.exit(1); // إيقاف التشغيل إذا لم يكن المفتاح موجودًا
}


// ================================
// 🪵 نظام تسجيل الأحداث (winston)
// ================================
const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.File({ filename: LOG_FILE }),
    new winston.transports.Console({ format: winston.format.combine(winston.format.colorize(), winston.format.simple()) })
  ],
  exceptionHandlers: [
    new winston.transports.File({ filename: ERR_LOG_FILE })
  ],
  rejectionHandlers: [
    new winston.transports.File({ filename: ERR_LOG_FILE })
  ]
});
// Ensure log directories exist
if (!fs.existsSync(path.dirname(LOG_FILE))) fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
if (!fs.existsSync(path.dirname(ERR_LOG_FILE))) fs.mkdirSync(path.dirname(ERR_LOG_FILE), { recursive: true });

// ================================
// 🖼️ تحميل الشعار عند بدء التشغيل
// ================================
let LOGO_BASE64 = '';
try {
  const logoPath = path.join(__dirname, 'public', 'images', 'logo.png');
  if (fs.existsSync(logoPath)) {
    const logoData = fs.readFileSync(logoPath);
    LOGO_BASE64 = 'data:image/png;base64,' + logoData.toString('base64');
    logger.info('✅ تم تحميل الشعار بنجاح (للفواتير).');
  } else {
    logger.warn('⚠️ ملف الشعار غير موجود في public/images/logo.png');
  }
} catch (e) {
  logger.error('❌ خطأ أثناء تحميل الشعار: ' + e.message);
}

// ================================
// 🚀 تهيئة Express و Middlewares
// ================================
const app = express();
app.use(cors({
    origin: true,
    credentials: true
}));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Security Headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      connectSrc: ["'self'", "https://fonts.googleapis.com", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdn.jsdelivr.net/npm/sweetalert2@11"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  }
}));

// Rate Limiter
const limiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests, please try again after a minute." },
});
app.use(limiter);

// Middleware لتسجيل الطلبات
const requestLogFile = path.join(__dirname, "data", "requests_log.json");
try {
  const logDir = path.dirname(requestLogFile);
  if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
  if (!fs.existsSync(requestLogFile)) fs.writeFileSync(requestLogFile, "[]", "utf8");
} catch (err) { logger.error("خطأ أثناء إعداد ملف سجل الطلبات: " + err.message); }

app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => {
        const duration = Date.now() - start;
        const logMessage = `${req.method} ${req.originalUrl} [Status: ${res.statusCode}] [Duration: ${duration}ms]`;
        logger.info(logMessage);

        // تسجيل الطلبات في ملف JSON باستخدام الإلحاق (لإصلاح التلف)
        const logEntry = {
            timestamp: new Date().toISOString(),
            method: req.method,
            endpoint: req.originalUrl,
            ip: req.ip,
            status: res.statusCode,
            duration_ms: duration
        };
        const logString = JSON.stringify(logEntry);
        // نلحق العنصر الجديد مسبوقًا بفاصلة ليكون مصفوفة JSON قابلة للاسترجاع لاحقاً
        fs.appendFile(requestLogFile, `,\n${logString}`, 'utf8', (err) => {
            if (err) logger.error("❌ فشل إلحاق سجل الطلبات (JSON):", err);
        });
    });
    next();
});

// ================================
// 🛠️ دوال مساعدة لإدارة المستخدمين والتسجيل
// ================================
const usersFile = path.join(__dirname, "data", "users.json");
const userActivityLogFile = path.join(__dirname, "logs", "user_activity.log");
const SALT_ROUNDS = parseInt(process.env.SALT_ROUNDS || '10', 10);

function logUserActivity(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}\n`;
  try {
    const logDir = path.dirname(userActivityLogFile);
    if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
    fs.appendFileSync(userActivityLogFile, logEntry, 'utf8');
  } catch (err) {
    logger.error(`فشل الكتابة في سجل نشاط المستخدم: ${err.message}`);
  }
}

async function getUsers() {
    try {
        if (!fs.existsSync(usersFile)) {
            logger.warn(`ملف المستخدمين '${path.basename(usersFile)}' غير موجود. سيتم إرجاع مصفوفة فارغة.`);
            return [];
        }
        return await readJSON(usersFile);
    } catch (error) {
        logger.error(`خطأ فادح أثناء قراءة ملف المستخدمين '${path.basename(usersFile)}': ${error.message}`);
        throw new Error('Could not load users data.');
    }
}

async function saveUsers(users) {
  try {
    await writeJSON(usersFile, users);
  } catch (error) {
    logger.error(`خطأ فادح أثناء كتابة ملف المستخدمين '${path.basename(usersFile)}': ${error.message}`);
    throw new Error('Could not save users data.');
  }
}

// ================================
// 🔗 نقاط نهاية API (Routes) - معرفة قبل express.static والحماية
// ================================

// --- API Test Endpoint ---
app.get("/api/test", (req, res) => {
    res.json({ success: true, message: "✅ السيرفر شغال بنجاح!" });
});

// --- API Login Endpoint ---
app.post("/api/login", async (req, res, next) => {
    try {
        const { username, password, role: requestedRole } = req.body;
        if (!username || !password) {
            return res.status(400).json({ success: false, message: "اسم المستخدم وكلمة المرور مطلوبان." });
        }

        const users = await getUsers();
        const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

        if (!user) {
            logger.warn(`محاولة دخول فاشلة — اسم المستخدم غير موجود: ${username}`);
            return res.status(401).json({ success: false, message: "اسم المستخدم أو كلمة المرور غير صحيحة." });
        }

        let match = false;
        if (user.password && user.password.startsWith('$2')) {
            match = await bcrypt.compare(password, user.password);
        } else if (password === user.password) {
            logger.warn(`User '${username}' logged in with an unhashed password. Please hash it.`);
            match = true;
        }

        if (!match) {
            logger.warn(`محاولة دخول بكلمة مرور خاطئة: ${username}`);
            return res.status(401).json({ success: false, message: "اسم المستخدم أو كلمة المرور غير صحيحة." });
        }

        const actualUserRole = user.role;
        if (actualUserRole === 'admin') {
            logger.info(`Admin user '${username}' logging in. Skipping UI role selection check.`);
        } else {
            if (!requestedRole) {
                logger.warn(`Non-admin user '${username}' (Role: ${actualUserRole}) attempted login without selecting a role.`);
                return res.status(400).json({ success: false, message: "⚠️ يرجى تحديد نوع الحساب (تاجر أو فني) قبل تسجيل الدخول." });
            }
            let roleCheckPassed = false;
            const techRoles = ['tech', 'plumber'];
            if (requestedRole === actualUserRole || (requestedRole === 'tech' && techRoles.includes(actualUserRole))) {
                roleCheckPassed = true;
            }
            if (!roleCheckPassed) {
                logger.warn(`Role mismatch for non-admin user '${username}': Requested '${requestedRole}', Actual '${actualUserRole}'`);
                return res.status(403).json({ success: false, message: "❌ نوع الحساب المحدد لا يتطابق مع بيانات الدخول." });
            }
        }

        if (user.status && user.status.toLowerCase() !== "active") {
            logger.warn(`محاولة دخول لمستخدم غير نشط: ${username}`);
            return res.status(403).json({ success: false, message: "الحساب غير نشط. يرجى مراجعة المسؤول." });
        }

        const { password: _pw, ...userPayload } = user;
        const token = jwt.sign(userPayload, process.env.JWT_SECRET, { expiresIn: '8h' });

        res.cookie('authToken', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 8 * 60 * 60 * 1000
        });

        logger.info(`دخول ناجح للمستخدم: ${username} (Role: ${actualUserRole}). Token issued.`);
        res.json({ success: true, user: userPayload });

    } catch (err) {
        next(err);
    }
});

// --- API Logout Endpoint ---
app.post("/api/logout", (req, res) => {
    res.cookie('authToken', '', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        expires: new Date(0)
    });
    logger.info(`User logged out. Token cookie cleared.`);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.status(200).json({ success: true, message: "Logged out successfully" });
});

// ================================
// 🔐 Middleware للحماية (Admin)
// ================================
const requireAdmin = (req, res, next) => {
    const token = req.cookies.authToken;
    if (!token) {
        logger.warn(`Admin Access Denied (No Token): ${req.method} ${req.originalUrl}`);
        if (req.accepts('html')) {
            return res.redirect('/login.html');
        }
        return res.status(401).json({ success: false, message: 'Unauthorized: No token provided.' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;

        if (decoded.role !== 'admin') {
            logger.warn(`Admin Access Denied (Not Admin): User='${decoded.username}', Role='${decoded.role}' to ${req.method} ${req.originalUrl}`);
             if (req.accepts('html')) {
                return res.redirect('/login.html?error=forbidden');
            }
            return res.status(403).json({ success: false, message: 'Forbidden: Admin privileges required.' });
        }

        next();

    } catch (err) {
        logger.warn(`Admin Access Denied (Invalid Token): ${err.message} for ${req.method} ${req.originalUrl}`);
        res.clearCookie('authToken');
         if (req.accepts('html')) {
            return res.redirect('/login.html?error=invalid_token');
        }
        return res.status(401).json({ success: false, message: 'Unauthorized: Invalid or expired token.' });
    }
};

// Apply admin protection to user management API routes
app.use('/api/users', requireAdmin);

// --- API User Management Endpoints ---
app.get("/api/users", async (req, res, next) => {
    try {
        const users = await getUsers();
        const safeUsers = users.map(({ password, ...userWithoutPassword }) => userWithoutPassword);
        res.json({ success: true, users: safeUsers });
    } catch (err) {
        next(err);
    }
});

app.post("/api/users", async (req, res, next) => {
    try {
        const { username, password, fullname, role, status } = req.body;
        const validRoles = ['trader', 'technician', 'plumber', 'admin'];
        const validStatuses = ['active', 'inactive'];

        if (!username || !password || !fullname || !role || !status) {
            return res.status(400).json({ success: false, message: "البيانات المطلوبة غير كاملة (username, password, fullname, role, status)." });
        }
        if (!validRoles.includes(role)) {
            return res.status(400).json({ success: false, message: `الدور '${role}' غير صالح. الأدوار المسموحة: ${validRoles.join(', ')}` });
        }
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, message: `الحالة '${status}' غير صالحة. الحالات المسموحة: ${validStatuses.join(', ')}` });
        }

        const users = await getUsers();
        const existingUser = users.find(u => u.username.toLowerCase() === username.toLowerCase());
        if (existingUser) {
            return res.status(409).json({ success: false, message: `اسم المستخدم '${username}' موجود بالفعل.` });
        }

        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        const newUser = { username, password: hashedPassword, fullname, role, status };
        users.push(newUser);
        await saveUsers(users);

        logUserActivity(`تمت إضافة مستخدم جديد: ${username} (Role: ${role}, Status: ${status})`);
        const { password: _pw, ...safeNewUser } = newUser;
        res.status(201).json({ success: true, message: "تمت إضافة المستخدم بنجاح.", user: safeNewUser });
    } catch (err) {
        next(err);
    }
});

app.put("/api/users/:username", async (req, res, next) => {
    try {
        const targetUsername = req.params.username;
        const updates = req.body;
        const validRoles = ['trader', 'technician', 'plumber', 'admin'];
        const validStatuses = ['active', 'inactive'];

        if (updates.username && updates.username.toLowerCase() !== targetUsername.toLowerCase()) {
            return res.status(400).json({ success: false, message: "لا يمكن تغيير اسم المستخدم عبر هذا الطلب." });
        }

        const users = await getUsers();
        const userIndex = users.findIndex(u => u.username.toLowerCase() === targetUsername.toLowerCase());

        if (userIndex === -1) {
            return res.status(404).json({ success: false, message: `المستخدم '${targetUsername}' غير موجود.` });
        }

        const userToUpdate = { ...users[userIndex] };
        let changesMade = [];

        if (updates.password && updates.password.trim() !== "") {
            userToUpdate.password = await bcrypt.hash(updates.password, SALT_ROUNDS);
            changesMade.push("password");
        }
        if (updates.fullname !== undefined && updates.fullname !== userToUpdate.fullname) {
            userToUpdate.fullname = updates.fullname;
            changesMade.push("fullname");
        }
        if (updates.role && updates.role !== userToUpdate.role) {
            if (!validRoles.includes(updates.role)) {
                return res.status(400).json({ success: false, message: `الدور '${updates.role}' غير صالح.` });
            }
            userToUpdate.role = updates.role;
            changesMade.push("role");
        }
        if (updates.status && updates.status !== userToUpdate.status) {
            if (!validStatuses.includes(updates.status)) {
                return res.status(400).json({ success: false, message: `الحالة '${updates.status}' غير صالحة.` });
            }
            userToUpdate.status = updates.status;
            changesMade.push("status");
        }

        if (changesMade.length === 0) {
            const { password: _pw, ...safeCurrentUser } = userToUpdate;
             return res.status(200).json({ success: true, message: "لا توجد تغييرات لتطبيقها.", user: safeCurrentUser });
        }

        users[userIndex] = userToUpdate;
        await saveUsers(users);

        logUserActivity(`تم تحديث المستخدم: ${targetUsername}. التغييرات: [${changesMade.join(', ')}]`);
        const { password: _pw, ...safeUpdatedUser } = userToUpdate;
        res.json({ success: true, message: "تم تحديث المستخدم بنجاح.", user: safeUpdatedUser });
    } catch (err) {
        next(err);
    }
});

app.delete("/api/users/:username", async (req, res, next) => {
    try {
        const targetUsername = req.params.username;
        const users = await getUsers();
        const initialLength = users.length;
        const updatedUsers = users.filter(u => u.username.toLowerCase() !== targetUsername.toLowerCase());

        if (updatedUsers.length === initialLength) {
            return res.status(404).json({ success: false, message: `المستخدم '${targetUsername}' غير موجود.` });
        }

        await saveUsers(updatedUsers);
        logUserActivity(`تم حذف المستخدم: ${targetUsername}`);
        res.json({ success: true, message: `تم حذف المستخدم '${targetUsername}' بنجاح.` });
    } catch (err) {
        next(err);
    }
});

// ================================
// 🛒 API for Quick Mode Data
// ================================

// Middleware to check if user is logged in (using JWT cookie) - Apply to all QM endpoints
const requireLogin = (req, res, next) => {
    const token = req.cookies.authToken;
    if (!token) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Please log in.' });
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        logger.warn(`Invalid/Expired token access attempt: ${err.message}`);
        res.clearCookie('authToken');
        return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token.' });
    }
};

// GET /api/sections - Get unique brand names (Sections)
app.get("/api/sections", requireLogin, async (req, res, next) => {
    try {
        let productsToUse = [];
        const now = Date.now();
        if (cachedProducts && now - lastFetchTime < CACHE_DURATION) {
            productsToUse = cachedProducts;
            logger.info("⚡ QM: Using in-memory cache for sections.");
        } else {
            const fileCache = loadProductsFromCacheFile();
            if(fileCache) {
                productsToUse = fileCache;
                logger.info("⚡ QM: Using file cache for sections.");
            } else {
                logger.info("🌐 QM: Fetching live products for sections...");
                productsToUse = await fetchProductsFromSheetGS();
            }
        }

        if (!Array.isArray(productsToUse)) {
             throw new Error("Product data is not available or invalid.");
        }

        const sections = Array.from(new Set(productsToUse.map(p => p && p.brand ? p.brand : "عام").filter(Boolean))).sort();
        res.json({ success: true, sections: sections });
    } catch (err) {
        next(err);
    }
});

// GET /api/items - Get items, optionally filtered by section and search query
app.get("/api/items", requireLogin, async (req, res, next) => {
    try {
        const { section, q } = req.query;

        let productsToUse = [];
         const now = Date.now();
        if (cachedProducts && now - lastFetchTime < CACHE_DURATION) {
            productsToUse = cachedProducts;
             logger.info("⚡ QM: Using in-memory cache for items.");
        } else {
            const fileCache = loadProductsFromCacheFile();
            if(fileCache) {
                 productsToUse = fileCache;
                 logger.info("⚡ QM: Using file cache for items.");
            } else {
                 logger.info("🌐 QM: Fetching live products for items...");
                 productsToUse = await fetchProductsFromSheetGS();
            }
        }

         if (!Array.isArray(productsToUse)) {
             throw new Error("Product data is not available or invalid.");
        }

        let filteredItems = productsToUse;

        if (section) {
            filteredItems = filteredItems.filter(p => p && p.brand === section);
        }

        if (q) {
            const searchTerm = q.trim().toLowerCase();
            if (searchTerm) {
                filteredItems = filteredItems.filter(p => p && p.name && p.name.toLowerCase().includes(searchTerm));
            }
        }

        const responseItems = filteredItems.map(p => ({
            id: p.id || p.system_code,
            name: p.name,
            price: p.price,
            brand: p.brand
        }));

        res.json({ success: true, items: responseItems });

    } catch (err) {
        next(err);
    }
});


// --- API Products Endpoint (with Caching) ---
let cachedProducts = null;
let lastFetchTime = 0;
const CACHE_DURATION = CACHE_HOURS * 60 * 60 * 1000;

function loadProductsFromCacheFile() {
  try {
    if (fs.existsSync(CACHE_FILE)) {
      const stats = fs.statSync(CACHE_FILE);
      const ageHours = (Date.now() - stats.mtimeMs) / (1000 * 60 * 60);
      if (ageHours < CACHE_HOURS) {
          const raw = fs.readFileSync(CACHE_FILE, "utf8");
          const products = JSON.parse(raw);
          if (Array.isArray(products)) {
              return products;
          } else {
               logger.warn(`ملف الكاش (${path.basename(CACHE_FILE)}) لا يحتوي على مصفوفة صالحة.`);
          }
      } else {
          logger.info(`ملف الكاش (${path.basename(CACHE_FILE)}) أقدم من ${CACHE_HOURS} ساعة.`);
      }
    }
  } catch (err) { logger.warn(`⚠️ فشل قراءة أو تحليل ملف الكاش (${path.basename(CACHE_FILE)}): ${err.message}`); }
  return null;
}

async function fetchProductsFromSheetGS() {
     logger.info("Function fetchProductsFromSheetGS called - Needs implementation");
     try {
         if (!GOOGLE_KEYFILE || !SPREADSHEET_ID) { throw new Error("GOOGLE_KEYFILE or SPREADSHEET_ID is not defined."); }
          if (!fs.existsSync(GOOGLE_KEYFILE)) { throw new Error(`Google Keyfile not found at ${GOOGLE_KEYFILE}`); }
         const serviceAccountAuth = new JWT({ keyFile: GOOGLE_KEYFILE, scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"] });
         const doc = new GoogleSpreadsheet(SPREADSHEET_ID, serviceAccountAuth);
         await doc.loadInfo();
         const sheet = doc.sheetsByTitle["Products"];
         if (!sheet) { throw new Error("Sheet 'Products' not found."); }
         const rows = await sheet.getRows();

         const products = rows.map(row => ({
             system_code: row.get('system_code') || "",
             system_name: row.get('system_name') || "",
             price: parseFloat(row.get('price')) || 0,
             brand: row.get('brand') || "عام",
             id: row.get('system_code') || `row${row.rowIndex}`
         })).filter(p => p.system_code && p.system_name);

         logger.info(`✅ تم تحميل ${products.length} منتج صالح من Google Sheets.`);
         return products;
     } catch (error) {
         logger.error("❌ خطأ أثناء قراءة البيانات من Google Sheets:", error.message);
         if (typeof sendErrorAlert === "function") {
             sendErrorAlert("🚨 خطأ في تحميل بيانات Google Sheets", `<pre>Error: ${error.message}\n${error.stack || ''}</pre>`);
         }
         throw error;
     }
}


app.get("/api/products", async (req, res, next) => {
    try {
        const now = Date.now();
        if (cachedProducts && now - lastFetchTime < CACHE_DURATION) {
            logger.info("⚡ تم جلب المنتجات من الكاش الداخلي");
            return res.json(cachedProducts);
        }
        const cachedFromFile = loadProductsFromCacheFile();
        if (cachedFromFile) {
            cachedProducts = cachedFromFile;
            try {
                 lastFetchTime = fs.statSync(CACHE_FILE).mtimeMs;
            } catch (statErr) {
                 logger.warn(`Could not get file stats for ${CACHE_FILE}, using current time.`);
                 lastFetchTime = now;
            }
             logger.info("⚡ تم تحميل المنتجات من ملف الكاش المحلي");
             return res.json(cachedProducts);
        }
        logger.info("🌐 جلب المنتجات من Google Sheets (live)...");
        const products = await fetchProductsFromSheetGS();
        cachedProducts = products || [];
        lastFetchTime = Date.now();
        if (cachedProducts.length > 0) {
            try { if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true }); }
            catch(mkdirErr){ logger.error(`Error creating cache directory ${CACHE_DIR}: ${mkdirErr.message}`); }

            fs.writeFile(CACHE_FILE, JSON.stringify(cachedProducts, null, 2), "utf8", (writeErr) => {
                if (writeErr) { logger.warn(`⚠️ تعذر حفظ الكاش في الملف (${path.basename(CACHE_FILE)}): ${writeErr.message}`); }
                else { logger.info(`💾 تم تحديث الكاش المحلي (${cachedProducts.length} منتج).`); }
            });
        } else {
             logger.warn("⚠️ لم يتم جلب أي منتجات صالحة من Google Sheets، لن يتم تحديث ملف الكاش.");
        }
        res.json(cachedProducts);
    } catch (err) {
        logger.error("❌ خطأ في /api/products: " + (err.message || err));
        next(err);
    }
});


// ================================
// 🔐 Middleware للحماية (المستخدم العادي - للصفحات)
// (مُعدل لاستثناء index.html وتعريف req.user للزوار)
// ================================
const requirePageLogin = (req, res, next) => {
    const publicPaths = ['/', '/index.html', '/login.html'];
    const isPublicAsset = req.originalUrl.startsWith('/js/') ||
                          req.originalUrl.startsWith('/css/') ||
                          req.originalUrl.startsWith('/images/') ||
                          req.originalUrl.endsWith('.ttf') ||
                          req.originalUrl.endsWith('.ico');

    if (publicPaths.includes(req.originalUrl) || isPublicAsset) {
        // إرفاق req.user بـ null للطلبات العامة لتجنب خطأ "reading 'role'"
        req.user = null;
        return next(); // السماح بالمرور بدون التحقق من التوكن
    }

    const token = req.cookies.authToken;
    if (!token) {
        logger.warn(`محاولة وصول لصفحة محمية (لا يوجد توكن): ${req.originalUrl}`);
        res.clearCookie('authToken');
        return res.redirect('/login.html'); // توجيه لصفحة الدخول فقط
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        logger.warn(`Invalid/Expired token access attempt to page: ${err.message} for ${req.originalUrl}`);
        res.clearCookie('authToken');
        return res.redirect('/login.html');
    }
};


// --- API Submit Order Endpoint ---
app.post("/api/submit-order", requireLogin, async (req, res, next) => {
    try {
        const order = req.body;
        if (!order || !order.items || !Array.isArray(order.items) || order.items.length === 0) {
            logger.warn("⚠️ محاولة إرسال طلب فارغ أو بتنسيق غير صحيح.");
            return res.status(400).json({ success: false, message: "السلة فارغة أو الطلب غير صحيح." });
        }
        if (!order.items.every(item => item && item.id && item.name && typeof item.qty === 'number' && typeof item.price === 'number')) {
             logger.warn("⚠️ تنسيق الأصناف في الطلب غير صحيح.");
             return res.status(400).json({ success: false, message: "تنسيق بعض الأصناف في الطلب غير صحيح." });
        }

        if (req.user && req.user.username && order.technicianName !== undefined) {
             logger.info(`Authenticated user '${req.user.username}' is submitting order ${order.id}`);
        }

        logger.info(`📨 استلام طلب جديد برقم: ${order.id || 'N/A'} من العميل: ${order.client || 'N/A'} (المكان: ${order.place || 'N/A'})`);

        let pdfPath;
        try {
            pdfPath = await generateOrderPDF(order);
        } catch (pdfErr) {
            logger.error(`❌ فشل إنشاء PDF للطلب ${order.id}: ${pdfErr.message}`, { stack: pdfErr.stack });
            logger.warn(`⚠️ سيتم إرسال الطلب ${order.id} كنص فقط كبديل.`);
            await sendTelegramMessage(order);
            return res.json({ success: true, message: "تم استلام الطلب (كنص) ولكن فشل إنشاء PDF." });
        }

        await sendTelegramDocument(pdfPath, order);
        res.json({ success: true, message: "تم استلام الطلب وجاري إرسال الفاتورة (PDF) للمعرض." });

    } catch (err) {
        next(err);
    }
});

// ================================
// 🔒 حماية مسار الأدمن
// ================================
app.use('/admin', requireAdmin, express.static(path.join(__dirname, 'public', 'admin')));
app.get('/admin/admin.html', requireAdmin, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin', 'admin.html'));
});


// ================================
// 🔒 حماية صفحات التطبيق الرئيسية (تأتي قبل express.static)
// ================================

// --- 🔽 تطبيق middleware الحماية أولاً على كل المسارات ---
// هذا سيضيف req.user للمسجلين و req.user=null للعامة
app.use(requirePageLogin);
// --- 🔼 ---

// --- 1. معالج المسار الرئيسي / ---
// الآن req.user سيكون موجودًا دائمًا (إما بيانات المستخدم أو null)
app.get('/', (req, res) => {
    // إذا كان req.user موجودًا وبه بيانات (أي المستخدم مسجل الدخول)
    // --- الحل النهائي هنا: req.user تم تعيينه لـ null للزوار في requirePageLogin
    if (req.user && req.user.role) {
        const userRole = req.user.role;
        if (userRole === 'admin') {
            return res.redirect('/admin/admin.html');
        } else if (userRole === 'trader') {
            return res.redirect('/index-trader.html');
        } else if (userRole === 'plumber' || userRole === 'tech') {
            return res.redirect('/index-technician.html');
        } else {
            logger.warn(`User ${req.user.username} with unknown role ${userRole} accessed root.`);
            return res.redirect('/index-technician.html');
        }
    } else {
        // إذا كان req.user هو null (زائر)
        logger.info("Guest or unauthenticated user accessed root '/'. Serving /index.html");
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    }
});
// --- 🔼 نهاية تعديل مسار الجذر / ---


// --- 2. تأمين صفحات الفاتورة (التاجر والفني) ---
const protectedAppPages = [
    'index-trader.html',
    'index-technician.html'
];

protectedAppPages.forEach(page => {
    app.get(`/${page}`, (req, res) => {
        if (!req.user || !req.user.role) {
             logger.error(`Error: User object missing role after requirePageLogin for protected page: ${page}`);
             // بما أن requirePageLogin نجح، لكن req.user لا يحتوي على بيانات، نعيد التوجيه إلى تسجيل الدخول.
             return res.redirect('/login.html');
        }

        const userRole = req.user.role;
        const username = req.user.username;
        let isAllowed = false;

        if (userRole === 'admin') {
            isAllowed = true;
        } else if (page === 'index-trader.html' && userRole === 'trader') {
            isAllowed = true;
        } else if (page === 'index-technician.html' && (userRole === 'plumber' || userRole === 'tech')) {
            isAllowed = true;
        }

        if (!isAllowed) {
             logger.warn(`Forbidden: User ${username} (Role: ${userRole}) tried to access restricted page ${page}.`);
             return res.status(403).redirect('/login.html?error=role_mismatch');
        }

        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');

        res.sendFile(path.join(__dirname, 'public', page));
    });
});


// ================================
// 📁 تقديم الملفات الثابتة (يأتي بعد تعريف مسارات API والحماية)
// ================================
app.use(express.static(path.join(__dirname, "public")));


// ================================
// ⚠️ مسار اختبار الأخطاء
// ================================
app.get("/api/test-error", (req, res, next) => {
    try {
        throw new Error("🧨 اختبار خطأ تجريبي من /api/test-error");
    } catch (err) {
        next(err);
    }
});

// ================================
// ❗ معالج الأخطاء العام (يجب أن يكون الأخير)
// ================================
app.use((err, req, res, next) => {
    const timestamp = new Date().toISOString();
    const errorDetails = `[${timestamp}] ${req.method} ${req.originalUrl} [IP: ${req.ip}] \nError: ${err.message}\nStack: ${err.stack || 'N/A'}\n---`;
    logger.error(errorDetails);

    if (typeof sendErrorAlert === "function") {
        sendErrorAlert(`🚨 خطأ في السيرفر (${req.method} ${req.originalUrl})`, `<pre>${errorDetails}</pre>`)
            .catch(e => logger.error("❌ فشل في إرسال تنبيه الخطأ عبر البريد: " + e.message));
    }

    if (err.name === 'UnauthorizedError' || err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
        res.clearCookie('authToken');
        if (req.accepts('html')) {
             return res.redirect('/login.html');
        }
        return res.status(401).json({ success: false, message: 'Unauthorized or Invalid Token.' });
    }

    if (res.headersSent) {
        return next(err);
    }

    res.status(err.status || 500).json({
        success: false,
        message: "حدث خطأ داخلي في السيرفر. يرجى المحاولة مرة أخرى لاحقًا أو الاتصال بالدعم.",
        ...(process.env.NODE_ENV === 'development' && { error_code: err.code, details: err.message })
    });
});

// ================================
// 🎧 بدء تشغيل السيرفر
// ================================
const server = app.listen(PORT, () => {
    logger.info(`🚀 السيرفر يعمل الآن على http://localhost:${PORT}`);
    console.log(`✅ السيرفر يعمل على المنفذ ${PORT}`);
    fetchProductsFromSheetGS()
        .then(products => {
            cachedProducts = products || [];
            lastFetchTime = Date.now();
             try { if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true }); }
             catch(mkdirErr){ logger.error(`Error creating cache directory ${CACHE_DIR}: ${mkdirErr.message}`); }

            fs.writeFile(CACHE_FILE, JSON.stringify(cachedProducts, null, 2), "utf8", (err) => {
              if (err) logger.warn(`⚠️ فشل حفظ الكاش الأولي (${path.basename(CACHE_FILE)}): ${err.message}`);
              else logger.info(`💾 تم تحميل وتخزين الكاش الأولي (${cachedProducts.length} منتج).`);
            });
        })
        .catch(err => {
            logger.error(`❌ فشل تحميل الكاش الأولي من Google Sheets: ${err.message}. محاولة التحميل من الملف...`);
            const fileCache = loadProductsFromCacheFile();
            if(fileCache) {
                cachedProducts = fileCache;
                try {
                     lastFetchTime = fs.statSync(CACHE_FILE).mtimeMs;
                 } catch (statErr) {
                     logger.warn(`Could not get file stats for ${CACHE_FILE}, using current time.`);
                     lastFetchTime = Date.now();
                 }
                logger.info(`⚡ تم تحميل الكاش الأولي من الملف (${cachedProducts.length} منتج).`);
            } else {
                 logger.error(`❌ فشل تحميل الكاش الأولي من الملف أيضًا. قد لا تعمل واجهة المنتجات.`);
                 cachedProducts = [];
                 lastFetchTime = 0;
            }
        });
});

// ================================
// ⏳ مهمة Cron لتحديث الكاش دوريًا
// ================================
try {
    const hours = Math.max(1, Math.floor(CACHE_HOURS));
    const cronExpr = `0 */${hours} * * *`;
    if (cron.validate(cronExpr)) {
        cron.schedule(cronExpr, async () => {
            logger.info("🔄 Cron job: بدء تحديث الكاش من Google Sheets...");
            try {
                const products = await fetchProductsFromSheetGS();
                cachedProducts = products || [];
                lastFetchTime = Date.now();

                 if (cachedProducts.length > 0) {
                     try { if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true }); }
                     catch(mkdirErr){ logger.error(`Cron: Error creating cache directory ${CACHE_DIR}: ${mkdirErr.message}`); }

                     fs.writeFile(CACHE_FILE, JSON.stringify(cachedProducts, null, 2), "utf8", (err) => {
                         if (err) logger.warn(`⚠️ Cron: فشل حفظ الكاش المحدث (${path.basename(CACHE_FILE)}): ${err.message}`);
                         else logger.info(`✅ Cron: تم تحديث الكاش بنجاح (${cachedProducts.length} منتج).`);
                     });
                 } else {
                      logger.warn("⚠️ Cron: لم يتم جلب أي منتجات صالحة من Google Sheets، لن يتم تحديث ملف الكاش.");
                 }
            } catch (err) {
                logger.error("❌ Cron error during fetch/update: " + (err.message || err));
            }
        });
        logger.info(`⏰ تم جدولة Cron job للتحديث كل ${hours} ساعة.`);
    } else {
         logger.warn(`⚠️ تعبير Cron غير صالح '${cronExpr}'. لن يتم تشغيل التحديث التلقائي.`);
    }
} catch (err) {
    logger.error("❌ فشل إعداد Cron job: " + err.message);
}


// ==================================================================
// 🔽🔽 (الكود الخاص بالفواتير والخصم) 🔽🔽
// (هذا الكود يعتمد على البيانات التي تم إرسالها من orderHandler.js)
// ==================================================================

function fmtCurrency(v) {
  try {
     return Number(v || 0).toLocaleString("ar-EG", { style: "currency", currency: "EGP", minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } catch (e) {
      return Number(v || 0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,') + " ج.م";
  }
}
function generateInvoiceHTML(order, logoBase64) {
    const discountEligibleBrands = ["BR باننجر", "كيسيل", "BR باننجر - اسود", "سمارت - Smart"];
    let grandTotalValue = 0;
    let eligibleItemsSubtotal = 0;
    order.items.forEach(item => {
        const itemTotal = (item.price || 0) * (item.qty || 0);
        grandTotalValue += itemTotal;
        if (discountEligibleBrands.includes(item.brand)) eligibleItemsSubtotal += itemTotal;
    });
    const grandTotalFormatted = fmtCurrency(grandTotalValue);
    const eligibleSubtotalFormatted = fmtCurrency(eligibleItemsSubtotal);
    let discountAmountValue = 0;
    let finalTotalValue = grandTotalValue;
    let discountApplied = false;
    let discountNote = "(لا يوجد خصم)";
    const isTechnician = order.technicianName !== undefined && order.technicianName !== null && order.technicianName !== '';
    const discountRate = isTechnician ? 0.03 : 0.04;
    const discountPercent = isTechnician ? "3%" : "4%";
    if (grandTotalValue >= 7000 && eligibleItemsSubtotal > 0) {
        discountAmountValue = eligibleItemsSubtotal * discountRate;
        finalTotalValue = grandTotalValue - discountAmountValue;
        discountApplied = true;
        const brandsInInvoiceEligibleForDiscount = Array.from(new Set(order.items.filter(item => discountEligibleBrands.includes(item.brand)).map(item => item.brand)));
        const technicianNotePart = isTechnician ? ` (خاص بالفني: ${order.technicianName})` : '';
        discountNote = `(تم تطبيق خصم ${discountPercent} على منتجات: ${brandsInInvoiceEligibleForDiscount.join('، ')})${technicianNotePart}`;
    }
    const discountAmountFormatted = fmtCurrency(discountAmountValue);
    const finalTotalFormatted = fmtCurrency(finalTotalValue);
    const css = `<style> @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap'); body { font-family: 'Cairo', sans-serif; direction: rtl; font-size: 10pt; } .container { width: 95%; margin: auto; } .header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 5px; margin-bottom: 15px; border-bottom: 1px solid #eee; } .logo { max-width: 80px; max-height: 80px; order: 2; } .info { order: 1; text-align: right; font-size: 0.9em; } .info h1 { margin: 0 0 5px 0; font-size: 1.1em; color: #b72025; font-weight: 700; } .info p { margin: 2px 0; font-weight: 600; font-size: 0.85em; } .info .contact { font-size: 0.75em; font-weight: normal; color: #333; } table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 0.8em; } th, td { border: 1px solid #ccc; padding: 4px 6px; } th { background-color: #f0f0f0; font-weight: 700; } th.col-num, td.col-num { text-align: center; width: 3%; } th.col-brand, td.col-brand { text-align: right; width: 15%; } th.col-code, td.col-code { text-align: right; width: 12%; } th.col-name, td.col-name { text-align: right; width: 40%; } th.col-qty, td.col-qty { text-align: center; width: 5%; } th.col-price, td.col-price { text-align: left; width: 10%; } th.col-total, td.col-total { text-align: left; width: 15%; } .totals-footer { text-align: left; margin-top: 15px; border-top: 2px solid #aaa; padding-top: 8px; font-size: 1.0em; } .total-row { font-weight: normal; margin-bottom: 4px; font-size: 0.9em; } .total-row span { font-weight: bold; } .discount-details { font-size: 0.8em; font-style: italic; color: #444; margin-top: 3px; } .final-total { font-weight: bold; font-size: 1.1em; color: #b72025; } td { word-wrap: break-word; } </style>`;
    const itemsRows = order.items.map((item, i) => `<tr><td class="col-num">${i + 1}</td><td class="col-brand">${item.brand || '-'}</td><td class="col-code">${item.id || '-'}</td><td class="col-name">${item.name || '-'}</td><td class="col-qty">${item.qty || 0}</td><td class="col-price">${fmtCurrency(item.price || 0)}</td><td class="col-total">${fmtCurrency((item.price || 0) * (item.qty || 0))}</td></tr>`).join('');
    let totalsHtml = `<div class="total-row">إجمالي الفاتورة (قبل الخصم): <span>${grandTotalFormatted}</span></div>`;
    if (discountApplied) {
        totalsHtml += `<div class="discount-details">إجمالي الأصناف المؤهلة للخصم: ${eligibleSubtotalFormatted}</div>`;
        totalsHtml += `<div class="total-row">قيمة الخصم (${discountPercent} من الأصناف المؤهلة): <span>${discountAmountFormatted}</span></div>`;
        totalsHtml += `<div class="total-row final-total">الإجمالي النهائي بعد الخصم: <span>${finalTotalFormatted}</span></div>`;
    } else {
        totalsHtml += `<div class="total-row final-total">الإجمالي النهائي: <span>${grandTotalFormatted}</span></div>`;
    }
    totalsHtml += `<div class="discount-details">${discountNote}</div>`;
    return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>فاتورة ${order.id}</title>${css}</head><body><div class="container"><div class="header">${logoBase64 ? `<img src="${logoBase64}" alt="Logo" class="logo">` : '<div></div>'}<div class="info"><h1>معرض حديث المدينة للسيراميك و الادوات الصحية</h1><p class="contact">(شارع ثابت امون بجوار المركز الطبي امام كنيسة الانجيلية)<br>ارقام التواصل : 01022577766 - 01226010025<br>https://www.facebook.com/1MSMN10</p><p><b>السادة / </b> ${order.client || 'غير محدد'}</p><p><b>التاريخ:</b> <span dir="ltr">${order.date || new Date().toLocaleString("ar-EG")}</span></p><p><b>رقم الطلب:</b> <span dir="ltr">${order.id || 'N/A'}</span></p><p><b>المكان:</b> ${order.place || 'غير محدد'}</p>${isTechnician ? `<p><b>المندوب:</b> ${order.technicianName || 'غير محدد'}</p>` : ''}</div></div><table><thead><tr><th class="col-num">م</th><th class="col-brand">القسم</th><th class="col-code">الكود</th><th class="col-name">اسم الصنف</th><th class="col-qty">الكمية</th><th class="col-price">السعر</th><th class="col-total">الاجمالي</th></tr></thead><tbody>${itemsRows}</tbody></table><br><div class="totals-footer">${totalsHtml}</div></div></body></html>`;
}
async function generateOrderPDF(order) {
    const pdfDir = path.join(__dirname, "invoices");
    if (!fs.existsSync(pdfDir)) { try { fs.mkdirSync(pdfDir, { recursive: true }); } catch(mkdirErr){ logger.error(`Error creating PDF directory ${pdfDir}: ${mkdirErr.message}`); throw mkdirErr; } }
    const pdfPath = path.join(pdfDir, `invoice-${order.id || Date.now()}.pdf`);
    let browser = null;
    try {
        logger.info(`⏳ بدء إنشاء PDF للطلب ${order.id}`);
        const executablePath = process.env.PUPPETEER_EXECUTABLE_PATH || undefined;
        const launchOptions = { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'], executablePath: executablePath };
        logger.debug('Puppeteer launch options:', launchOptions);
        browser = await puppeteer.launch(launchOptions);
        const page = await browser.newPage();
        const htmlContent = generateInvoiceHTML(order, LOGO_BASE64);
        try { await page.setContent(htmlContent, { waitUntil: 'networkidle0', timeout: 15000 }); }
        catch (setContentError) {
             logger.error(`Puppeteer setContent error for order ${order.id}: ${setContentError.message}`);
              try { await page.setContent(htmlContent, { waitUntil: 'domcontentloaded', timeout: 10000 }); }
              catch (setContentFallbackError) { logger.error(`Puppeteer setContent fallback error for order ${order.id}: ${setContentFallbackError.message}`); throw setContentFallbackError; }
        }
         try { await page.pdf({ path: pdfPath, format: 'A4', printBackground: true, margin: { top: '25px', right: '25px', bottom: '25px', left: '25px' } }); }
         catch(pdfGenError) { logger.error(`Puppeteer pdf generation error for order ${order.id}: ${pdfGenError.message}`); throw pdfGenError; }
        await browser.close(); browser = null;
        logger.info(`📄 تم إنشاء PDF بنجاح: ${path.basename(pdfPath)}`);
        return pdfPath;
    } catch (err) {
        logger.error(`❌ فشل إنشاء PDF (Puppeteer) للطلب ${order.id}: ${err.message}`, { stack: err.stack });
        if (browser) { try { await browser.close(); } catch (closeErr) { logger.error("Error closing browser after PDF failure:", closeErr);} }
        throw err;
    }
}
async function sendTelegramMessage(order) {
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID || TELEGRAM_BOT_TOKEN === "YOUR_BOT_TOKEN_HERE") { logger.warn("⚠️ (Text) لم يتم تكوين إعدادات تليجرام، تخطي الإرسال."); return; }
    const itemsList = order.items.map((item, idx) => `\n    ${idx + 1}. <b>${item.name || '-'}</b> (${item.brand || '-'}) - الكمية: ${item.qty} - الإجمالي: ${fmtCurrency((item.price || 0) * (item.qty || 0))}`).join('');
    const discountEligibleBrands = ["BR باننجر", "كيسيل", "BR باننجر - اسود", "سمارت - Smart"];
    let grandTotalValue = 0, eligibleItemsSubtotal = 0;
    order.items.forEach(item => { const itemTotal = (item.price || 0) * (item.qty || 0); grandTotalValue += itemTotal; if (discountEligibleBrands.includes(item.brand)) eligibleItemsSubtotal += itemTotal; });
    let discountAmountValue = 0, discountDetailsText = "", discountedBrands = [];
    const isTechnician = order.technicianName !== undefined && order.technicianName !== null && order.technicianName !== '';
    const discountRate = isTechnician ? 0.03 : 0.04, discountPercent = isTechnician ? "3%" : "4%";
    if (grandTotalValue >= 7000 && eligibleItemsSubtotal > 0) {
        discountAmountValue = eligibleItemsSubtotal * discountRate;
        discountDetailsText = `\n🔻 خصم (${discountPercent} من المؤهل): ${fmtCurrency(discountAmountValue)}`;
        discountedBrands.push(...Array.from(new Set(order.items.filter(item => discountEligibleBrands.includes(item.brand)).map(item => item.brand))));
    }
    const finalTotalValue = grandTotalValue - discountAmountValue;
    const message = `\n🔔 <b>طلب جديد (فاتورة سباك)</b> 🔔\n--------------------------------------\n<b>رقم الطلب:</b> ${order.id || 'N/A'} | <b>العميل:</b> ${order.client || 'غير محدد'} | <b>المكان:</b> ${order.place || 'غير محدد'}\n${isTechnician ? `<b>المندوب:</b> ${order.technicianName}\n` : ''} <b>تاريخ الطلب:</b> ${order.date || new Date().toLocaleString("ar-EG")}\n--------------------------------------\n<b>⬇️ الأصناف المطلوبة ⬇️</b>${itemsList}\n--------------------------------------\n💰 <b>إجمالي الفاتورة: ${fmtCurrency(grandTotalValue)}</b>${discountDetailsText}\n✅ <b>الإجمالي النهائي: ${fmtCurrency(finalTotalValue)}</b>\n${discountedBrands.length > 0 ? `<pre>(خصم مطبق على: ${discountedBrands.join(', ')})</pre>` : '<pre>(لا يوجد خصم)</pre>'}\n`;
    const telegramApiUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    try {
        await axios.post(telegramApiUrl, { chat_id: TELEGRAM_CHAT_ID, text: message, parse_mode: 'HTML' });
        logger.info(`✅ تم إرسال الطلب (نصي مع خصم) ${order.id} إلى تليجرام.`);
    } catch (err) {
        const errorMsg = err.response?.data?.description || err.message;
        logger.error(`❌ فشل إرسال رسالة تليجرام: ${errorMsg}`);
        if (typeof sendErrorAlert === "function") { sendErrorAlert("🚨 فشل إرسال رسالة Telegram", `<pre>Order ID: ${order.id}\nError: ${errorMsg}\n${err.stack || ''}</pre>`); }
    }
}
async function sendTelegramDocument(pdfPath, order) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID || TELEGRAM_BOT_TOKEN === "YOUR_BOT_TOKEN_HERE") { logger.warn("⚠️ (PDF) لم يتم تكوين إعدادات تليجرام، تخطي إرسال الـ PDF."); return; }
  const telegramApiUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`;
  const discountEligibleBrands = ["BR باننجر", "كيسيل", "BR باننجر - اسود", "سمارت - Smart"];
  let grandTotalValue = 0, eligibleItemsSubtotal = 0;
  order.items.forEach(item => { const itemTotal = (item.price || 0) * (item.qty || 0); grandTotalValue += itemTotal; if (discountEligibleBrands.includes(item.brand)) eligibleItemsSubtotal += itemTotal; });
  let discountAmountValue = 0, discountDetailsText = "", discountedBrands = [];
  const isTechnician = order.technicianName !== undefined && order.technicianName !== null && order.technicianName !== '';
  const discountRate = isTechnician ? 0.03 : 0.04, discountPercent = isTechnician ? "3%" : "4%";
  if (grandTotalValue >= 7000 && eligibleItemsSubtotal > 0) {
      discountAmountValue = eligibleItemsSubtotal * discountRate;
      discountDetailsText = `\n🔻 خصم (${discountPercent} من المؤهل): ${fmtCurrency(discountAmountValue)}`;
      discountedBrands.push(...Array.from(new Set(order.items.filter(item => discountEligibleBrands.includes(item.brand)).map(item => item.brand))));
  }
  const finalTotalValue = grandTotalValue - discountAmountValue;
  const finalTotalFormatted = fmtCurrency(finalTotalValue);
  const caption = `\n🔔 <b>طلب جديد (فاتورة PDF للمالك)</b> 🔔\n<b>العميل:</b> ${order.client || 'غير محدد'} | <b>المكان:</b> ${order.place || 'غير محدد'}\n${isTechnician ? `<b>المندوب:</b> ${order.technicianName}\n` : ''} --------------------------------------\n💰 <b>إجمالي الفاتورة: ${fmtCurrency(grandTotalValue)}</b>${discountDetailsText}\n✅ <b>الإجمالي النهائي: ${finalTotalFormatted}</b>\n${discountedBrands.length > 0 ? `<pre>(خصم مطبق على: ${discountedBrands.join(', ')})</pre>` : '<pre>(لا يوجد خصم)</pre>'}\n<pre>رقم الطلب: ${order.id}</pre>\n  `;
  const form = new FormData();
  form.append('chat_id', TELEGRAM_CHAT_ID);
  form.append('document', fs.createReadStream(pdfPath));
  form.append('caption', caption);
  form.append('parse_mode', 'HTML');
  const safeClientName = (order.client || 'Invoice').replace(/[^a-zA-Z0-9\u0600-\u06FF\s-]/g, '').substring(0, 30);
  const filename = `${safeClientName}-${order.id}.pdf`;
  form.append('file_name', filename);
  try {
    await axios.post(telegramApiUrl, form, { headers: { ...form.getHeaders() }, maxContentLength: Infinity, maxBodyLength: Infinity });
    logger.info(`✅ تم إرسال PDF للطلب ${order.id} إلى تليجرام.`);
  } catch (err) {
    const errorMsg = err.response?.data?.description || err.message;
    logger.error(`❌ فشل إرسال PDF تليجرام (Order ID: ${order.id}): ${errorMsg}`);
    logger.warn(`⚠️ سيتم محاولة إرسال رسالة نصية كبديل للطلب ${order.id}...`);
     try { await sendTelegramMessage(order); }
     catch (fallbackErr) {
          logger.error(`❌ فشل إرسال الرسالة النصية البديلة أيضًا (Order ID: ${order.id}): ${fallbackErr.message}`);
          if (typeof sendErrorAlert === "function") { sendErrorAlert("🚨 فشل إرسال رسالة Telegram (PDF والنص)", `<pre>Order ID: ${order.id}\nPDF Error: ${errorMsg}\nText Error: ${fallbackErr.message}\n${err.stack || ''}</pre>`); }
     }
  } finally {
    try { if (fs.existsSync(pdfPath)) { fs.unlinkSync(pdfPath); logger.info(`🗑️ تم حذف ملف PDF المؤقت: ${path.basename(pdfPath)}`); } }
    catch (unlinkErr) { logger.error(`⚠️ فشل حذف ملف PDF المؤقت (${path.basename(pdfPath)}): ${unlinkErr.message}`); }
  }
}
// ==================================================================
// 🔼🔼 (نهاية الكود الخاص بالفواتير) 🔼🔼
// ==================================================================


// Graceful shutdown
function gracefulShutdown(signal) {
  logger.info(`${signal} signal received: closing HTTP server`);
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
  setTimeout(() => { logger.error('Could not close connections in time, forcefully shutting down'); process.exit(1); }, 10000);
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));