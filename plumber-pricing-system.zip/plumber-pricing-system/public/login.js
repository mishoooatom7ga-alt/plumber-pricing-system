// public/js/login.js (مُعدل لتخزين الدور)
console.log("✅ login.js loaded");

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const usernameInput = document.getElementById("username"); // Corrected ID from login.html
  const passwordInput = document.getElementById("password"); // Corrected ID from login.html
  const submitBtn = document.getElementById("submitBtn"); // Corrected ID from login.html
  const statusEl = document.getElementById("status"); // Corrected ID from login.html
  // const loader = document.getElementById("loader"); // loader is integrated into the button now

  // Helper function for button loading state (assuming it's defined in login.html script)
  function setLoading(flag) {
      if (flag) {
        submitBtn.setAttribute('disabled','disabled');
        submitBtn.innerHTML = '<span style="display:inline-flex;align-items:center;gap:10px"><span class="spinner" aria-hidden="true"></span> جاري التحقق...</span>';
      } else {
        submitBtn.removeAttribute('disabled');
        // Revert button text/icon (adjust icon if needed)
        submitBtn.innerHTML = '<span id="btnContent" style="display:inline-flex;align-items:center;gap:10px">دخول</span>';
      }
  }
   // Helper function for status message (assuming it's defined in login.html script)
   function setStatus(msg='', type='') {
        statusEl.textContent = String(msg||'').replace(/[<>]/g,''); // Basic XSS protection
        statusEl.className = 'status'; // Reset classes
        if(type === 'error') statusEl.classList.add('error');
        else if(type === 'success') statusEl.classList.add('success');
    }


  if (form && usernameInput && passwordInput && submitBtn && statusEl) {
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        setStatus(''); // Clear previous status

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        if (!username || !password) {
          // Use Swal if available, otherwise use setStatus
          if (typeof Swal !== 'undefined') {
              Swal.fire("تنبيه", "من فضلك أدخل اسم المستخدم وكلمة المرور", "warning");
          } else {
              setStatus("من فضلك أدخل اسم المستخدم وكلمة المرور", "error");
          }
          return;
        }

        setLoading(true);

        try {
          const response = await fetch("/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password }),
          });

          const data = await response.json();

          if (data.success && data.user) {
            // --- 🔽 التخزين في sessionStorage 🔽 ---
            try {
                sessionStorage.setItem("loggedUser", JSON.stringify(data.user)); // Store user object (including role)
                console.log("User data stored in sessionStorage:", data.user);
            } catch (storageError) {
                console.error("Failed to store user data in sessionStorage:", storageError);
                // Handle potential storage full errors if necessary
            }
            // --- 🔼 ---

            // Use Swal for feedback if available
            if (typeof Swal !== 'undefined') {
                Swal.fire({ icon: "success", title: "تم تسجيل الدخول بنجاح!", timer: 1000, showConfirmButton: false });
            } else {
                setStatus("تم تسجيل الدخول بنجاح!", "success");
            }

            // Redirect after a short delay
            setTimeout(() => { window.location.href = "/index.html"; }, 1000);

          } else {
            // Login failed
             if (typeof Swal !== 'undefined') {
                 Swal.fire("خطأ", data.message || "فشل تسجيل الدخول", "error");
             } else {
                 setStatus(data.message || "فشل تسجيل الدخول", "error");
             }
             setLoading(false); // Re-enable button on failure
          }
        } catch (err) {
            console.error("Login fetch error:", err);
             if (typeof Swal !== 'undefined') {
                 Swal.fire("خطأ", "تعذر الاتصال بالسيرفر، تأكد أنه يعمل", "error");
             } else {
                setStatus("تعذر الاتصال بالسيرفر", "error");
             }
             setLoading(false); // Re-enable button on error
        }
        // No finally block needed here as setLoading(false) is handled in success/error paths
      });
      console.log("✅ Login form listener attached.");
  } else {
      console.error("❌ Could not find all required login form elements.");
  }

  // --- 🔽 (تصحيح 2: معالج زر الدخول كزائر يتحقق من حالة زر الإرسال الموجود مسبقًا) ---
  const guestBtn = document.getElementById('guestBtn'); // الحصول على زر الزائر
  // نفترض أن submitBtn معرف مسبقًا في نطاق السكربت داخل login.html
  // يجب التأكد من أن login.js يتم تحميله بعد السكربت المضمن في login.html
  if (guestBtn && typeof submitBtn !== 'undefined' && submitBtn) { // <<<--- تعديل التحقق ليشمل submitBtn المعرف مسبقًا
    guestBtn.addEventListener('click', function(e) {
      e.preventDefault(); // منع أي سلوك افتراضي للزر

      // التحقق مما إذا كان زر الإرسال الرئيسي معطلاً حاليًا (يعني أن عملية تسجيل الدخول جارية)
      if (submitBtn.disabled) { // <<<--- استخدام submitBtn المعرف مسبقًا
         console.warn("Guest button clicked while login submit is in progress. Ignoring.");
         return; // منع الضغط أثناء تحميل الدخول العادي
      }

      // مسح رسائل الحالة
      const statusEl = document.getElementById("status"); // الحصول على عنصر الحالة
      if (statusEl) statusEl.textContent = ''; // مسح الحالة مباشرة

      console.log("Guest button clicked. Redirecting to /index.html...");
      // توجيه مباشر إلى صفحة index.html
      window.location.href = '/index.html';
    });
    console.log("✅ Guest login button listener attached.");
  } else {
    if (!guestBtn) console.error("❌ Guest login button #guestBtn not found.");
    // التحقق إذا كان submitBtn غير معرف أو لا يمكن الوصول إليه
    if (typeof submitBtn === 'undefined' || !submitBtn) console.error("❌ Login submit button #submitBtn not found or not accessible from login.html scope (needed for guest button check).");
  }
  // --- 🔼 (نهاية التصحيح 2) ---

});