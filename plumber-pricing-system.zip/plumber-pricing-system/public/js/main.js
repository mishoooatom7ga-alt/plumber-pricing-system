// (ستتم إضافتها في بداية main.js)

/**
 * دالة آمنة لقراءة المستخدم الحالي من localStorage
 * @returns {Object | null} بيانات المستخدم أو null
 */
function getAuthenticatedUser() {
  try {
    const rawUser = localStorage.getItem("loggedUser");
    if (rawUser) {
      return JSON.parse(rawUser);
    }
    return null; // لا يوجد مستخدم مسجل
  } catch (e) {
    console.error("Failed to parse loggedUser", e);
    return null; // خطأ في البانات
  }
}

/**
 * يُنشئ مفتاح تخزين فريد بناءً على المستخدم
 * @param {string} baseKey - المفتاح الأساسي (مثل "cart" أو "orderId")
 * @returns {string | null} المفتاح الفريد (مثل "pps.Bina.cart") أو null
 */
function getUserStorageKey(baseKey) {
  const user = getAuthenticatedUser();
  if (user && user.username) {
    // نستخدم اسم المستخدم كمُعرف فريد
    return `pps.${user.username}.${baseKey}`;
  }
  // إذا لم يكن هناك مستخدم، لا تُرجع مفتاح
  return null;
}

window.onerror = function(msg, url, lineNo, columnNo, error) {
  console.error("🚨 Frontend Error Caught:");
  console.log("Message:", msg);
  console.log("File:", url);
  console.log("Line:", lineNo, "Column:", columnNo);
  console.log("Stack:", error?.stack);
  return false; // السماح للمعالج الافتراضي بالعمل
};


// public/js/main.js
console.log("✅ main.js loaded");

// =======================
// المتغيرات العامة
// =======================
let PRODUCTS = [];
let CART = [];
let SECTIONS = [];
let CURRENT_ORDER_ID = "";

// =======================
// دوال مساعدة عامة
// =======================
function fmtCurrency(v) {
  // تعرض السعر كاملاً (سنبقي عليها للاستخدامات الأخرى)
  return Number(v).toLocaleString("ar-EG", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ج.م";
}

// (هذه هي دالة التشفير المطلوبة)
function maskAmount(v) {
  const numStr = String(Math.floor(Number(v) || 0)); // الحصول على الجزء الصحيح كسلسلة
  const len = numStr.length;
  let maskedResult = "";

  if (len === 0) {
      maskedResult = "0"; // حالة الصفر
  } else if (len >= 1 && len <= 3) { // أقل من 1000 (نعرضه كما هو)
    maskedResult = numStr;
  } else if (len === 4) { // من 1000 إلى 9999
    maskedResult = numStr.substring(0, 1) + "***"; // أول رقم + ***
  } else if (len === 5) { // من 10000 إلى 99999
    maskedResult = numStr.substring(0, 2) + "***"; // أول رقمين + ***
  } else if (len === 6) { // من 100000 إلى 999999
    maskedResult = numStr.substring(0, 3) + "***"; // أول 3 أرقام + ***
  } else { // أرقام أكبر (نعرض أول 4 ونكمل نجوم)
    maskedResult = numStr.substring(0, 4) + '*'.repeat(len - 4);
  }

  return maskedResult + " ج"; // إضافة "ج" فقط
}


function randId() {
  return "ORD" + Math.floor(Math.random() * 900000 + 100000);
}

function setStatusHint(msg, type = "") {
  const statusHint = document.getElementById("formHint");
  if (!statusHint) return;
  statusHint.textContent = msg || "";
  if (type === "error") statusHint.style.color = "var(--danger)";
  else if (type === "success") statusHint.style.color = "var(--success)";
  else statusHint.style.color = "";
  setTimeout(() => {
    statusHint.style.color = "";
    statusHint.textContent = 'بعد إضافة الأصناف اضغط "احسب الإجمالي" لعرض المجموع على اليسار.';
  }, 2500);
}

// =======================
// تحميل المنتجات من السيرفر
// =======================
async function loadProducts() {
  try {
    const res = await fetch("/api/products", { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error("Invalid data format from server");

    PRODUCTS = data.map((p, idx) => ({
      id: p.system_code || `p${idx + 1}`,
      name: p.system_name || "اسم غير معروف",
      price: parseFloat(p.price) || 0,
      brand: p.brand || "عام",
    }));

    console.log(`✅ تم تحميل ${PRODUCTS.length} منتج من السيرفر`);
  } catch (e) {
    console.error("❌ فشل تحميل المنتجات من السيرفر:", e);
    setStatusHint(`خطأ في تحميل المنتجات: ${e.message}`, "error");
    if (PRODUCTS.length === 0) {
        console.warn("⚠️ سيتم استخدام بيانات تجريبية");
        PRODUCTS = [
          { id: "p1", brand: "تجريبي أ", name: "منتج تجريبي 1", price: 100.0 },
          { id: "p2", brand: "تجريبي ب", name: "منتج تجريبي 2", price: 250.5 },
        ];
    }
  }
}

// =======================
// إدارة السلة (تحميل/حفظ محلي)
// =======================
function saveCartToLocal() {
  // (تعديل: استخدام المفاتيح الفريدة)
  const cartKey = getUserStorageKey("cart");
  const orderIdKey = getUserStorageKey("orderId");

  // لا تقم بالحفظ إذا لم يكن هناك مستخدم
  if (!cartKey || !orderIdKey) {
    console.warn("⚠️ لا يمكن الحفظ، لا يوجد مستخدم مسجل.");
    return; 
  }

  try {
    localStorage.setItem(cartKey, JSON.stringify(CART));
    localStorage.setItem(orderIdKey, CURRENT_ORDER_ID);
  } catch (e) {
    console.warn("⚠️ لم يتم الحفظ المحلي للسلة", e);
  }
}

function loadCartFromLocal() {
  // (تعديل: استخدام المفاتيح الفريدة والتحقق الآمن)
  const cartKey = getUserStorageKey("cart");
  const orderIdKey = getUserStorageKey("orderId");

  // التحقق من وجود مستخدم (كما شرحت في النقطة ب)
  if (!cartKey || !orderIdKey) {
    // لا يوجد مستخدم، ابدأ بسلة فارغة ونظيفة
    CART = [];
    CURRENT_ORDER_ID = randId();
    console.log("No authenticated user, starting with a clean cart.");
    return;
  }

  try {
    // يوجد مستخدم، قم بتحميل بياناته الخاصة
    const rawCart = localStorage.getItem(cartKey);
    const rawOrderId = localStorage.getItem(orderIdKey);

    if (rawCart) {
        const parsedCart = JSON.parse(rawCart);
        if (Array.isArray(parsedCart)) CART = parsedCart;
        else CART = [];
    } else {
        CART = []; // ابدأ بسلة فارغة لهذا المستخدم
    }

    if (rawOrderId) CURRENT_ORDER_ID = rawOrderId;
    else CURRENT_ORDER_ID = randId(); // ابدأ بـ ID جديد لهذا المستخدم

  } catch (e) {
    console.warn("⚠️ لم يتم تحميل السلة المحلية أو ID الطلب", e);
    CART = [];
    CURRENT_ORDER_ID = randId();
  }
}

// =======================
// التهيئة العامة
// =======================
async function initApp() {
  console.log("⏳ Initializing App...");
  loadCartFromLocal();
  if (!CURRENT_ORDER_ID) CURRENT_ORDER_ID = randId();
  console.log(`🛒 CART loaded: ${CART.length} items. Order ID: ${CURRENT_ORDER_ID}`);
  await loadProducts();

  if (typeof renderBrands === "function") renderBrands();
  if (typeof renderProductsForBrand === "function") renderProductsForBrand("");
  if (typeof renderCartPreview === "function") renderCartPreview();

   try {
     const rawUser = localStorage.getItem('loggedUser');
     if(rawUser){
       const user = JSON.parse(rawUser);
       const userNameEl = document.getElementById('userName');
       if(userNameEl) userNameEl.textContent = user.name || user.username || 'مستخدم';
     }
   } catch(e) { console.warn("Could not load user info", e); }
   console.log("✅ App Initialized!");
}