// public/js/uiManager.js (Includes Keyboard Navigation Logic)
console.log("✅ uiManager.js loaded");

// ======= عرض الأقسام (Brands) =======
window.renderBrands = function() {
  const brandSelect = document.getElementById("brandSelect");
  if (!brandSelect) {
      console.error("❌ Element #brandSelect not found for rendering brands.");
      return;
  }
  if (typeof PRODUCTS === 'undefined' || !Array.isArray(PRODUCTS)) {
      console.warn("⚠️ PRODUCTS array not available for rendering brands. Initializing as empty.");
      PRODUCTS = [];
  }
  const sections = Array.from(new Set(PRODUCTS.map(p => p && p.brand ? p.brand : "عام").filter(Boolean))).sort();

  brandSelect.innerHTML = '<option value="" disabled selected hidden>-- اختر القسم --</option>';
  sections.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s;
    opt.textContent = s;
    brandSelect.appendChild(opt);
  });
  console.log(`📊 Rendered ${sections.length} brands.`);
};

// ======= عرض المنتجات حسب القسم (Populates the main dropdown) =======
window.renderProductsForBrand = function(brand = "") {
  const productSelect = document.getElementById("productSelect");
  if (!productSelect) {
      console.error("❌ Element #productSelect not found for rendering products.");
      return;
  }
  if (typeof PRODUCTS === 'undefined' || !Array.isArray(PRODUCTS)) {
      console.warn("⚠️ PRODUCTS array not available for rendering products.");
      PRODUCTS = [];
  }

  productSelect.innerHTML = '<option value="">-- اختر الصنف --</option>'; // Always start fresh

  if (!brand) {
      // console.log("No brand selected, product list cleared."); // Optional
      return;
  }

  // Filter products strictly by the selected brand
  const brandProducts = PRODUCTS.filter(p => p && p.brand === brand);
  console.log(`Found ${brandProducts.length} products for brand "${brand}" to populate dropdown.`);

  if (brandProducts.length > 0) {
      brandProducts.forEach(p => {
          if (!p || !p.id || !p.name) {
              console.warn("Skipping invalid product data during render:", p);
              return;
          }
          const opt = document.createElement("option");
          opt.value = p.id; // Use product ID as value
          opt.textContent = p.name;
          productSelect.appendChild(opt);
      });
  } else {
      console.log("Selected brand has no products.");
      const opt = document.createElement("option");
      opt.textContent = "لا توجد أصناف لهذا القسم";
      opt.disabled = true;
      productSelect.appendChild(opt);
  }
};


// ======= عرض الاقتراحات وإخفائها =======
function showSuggestions(suggestions) {
    const suggestionsList = document.getElementById('suggestionsList');
    const productSearch = document.getElementById('productSearch');
    if (!suggestionsList || !productSearch) return;

    suggestionsList.innerHTML = ''; // Clear previous
    // Remove any previous keyboard highlight
    const highlighted = suggestionsList.querySelector('.suggestion-highlight');
    if (highlighted) highlighted.classList.remove('suggestion-highlight');

    if (suggestions.length === 0 || productSearch.value.trim().length < 1) {
        suggestionsList.style.display = 'none';
        return;
    }

    suggestions.forEach(product => {
        const div = document.createElement('div');
        div.textContent = product.name;
        div.dataset.productId = product.id;
        div.dataset.productName = product.name;

        div.addEventListener('mousedown', (e) => {
            e.preventDefault();
            const searchInput = document.getElementById('productSearch');
            const mainSelect = document.getElementById('productSelect');
            if (searchInput && mainSelect) {
                searchInput.value = product.name;
                mainSelect.value = product.id;
                console.log(`Suggestion selected: Product ID ${product.id}`);
            }
            hideSuggestionsImmediately();
            document.getElementById('qty')?.focus();
        });
        suggestionsList.appendChild(div);
    });

    suggestionsList.style.display = 'block';
}

// Function to hide suggestions with a delay (on blur)
function hideSuggestionsWithDelay() {
    const suggestionsList = document.getElementById('suggestionsList');
    if (suggestionsList) {
        setTimeout(() => {
             const activeElement = document.activeElement;
             const searchContainer = document.getElementById('searchContainer');
             if (!searchContainer || !searchContainer.contains(activeElement)) {
                suggestionsList.style.display = 'none';
                // Also remove highlight when hiding with delay
                const highlighted = suggestionsList.querySelector('.suggestion-highlight');
                if (highlighted) highlighted.classList.remove('suggestion-highlight');
             }
        }, 150);
    }
}
// Function to hide suggestions immediately
function hideSuggestionsImmediately() {
    const suggestionsList = document.getElementById('suggestionsList');
    if (suggestionsList) {
        suggestionsList.style.display = 'none';
        // Also remove highlight when hiding immediately
        const highlighted = suggestionsList.querySelector('.suggestion-highlight');
        if (highlighted) highlighted.classList.remove('suggestion-highlight');
    }
}

// ======= ربط الأحداث (Event Listeners) =======
document.addEventListener("DOMContentLoaded", () => {
  console.log("🔧 uiManager: DOMContentLoaded - Attaching listeners...");

  const brandSelect = document.getElementById("brandSelect");
  const productSearch = document.getElementById("productSearch");
  const searchContainer = document.getElementById("searchContainer");
  const productSelectElement = document.getElementById("productSelect"); // Renamed for clarity
  const searchHint = document.getElementById("searchHint");
  const suggestionsList = document.getElementById("suggestionsList"); // Ensure suggestionsList is defined here

  // --- Listener for Brand Selection ---
  if (brandSelect && searchContainer && productSearch && productSelectElement && searchHint && suggestionsList) {
    brandSelect.addEventListener("change", (e) => {
      const selectedBrand = e.target.value;
      console.log(`Brand selected: "${selectedBrand}"`);
      hideSuggestionsImmediately();

      if (selectedBrand) {
        searchContainer.style.display = "block";
        productSearch.value = "";
        searchHint.textContent = "";
        renderProductsForBrand(selectedBrand);
        try { productSearch.focus(); } catch (focusError) { console.warn("Could not focus search input:", focusError); }
      } else {
        searchContainer.style.display = "none";
        productSearch.value = "";
        searchHint.textContent = "";
        renderProductsForBrand("");
      }
    });
    console.log("✅ Brand selection listener attached.");
  } else {
    console.error("❌ Missing one or more elements for brand selection listener.");
  }

  // --- Listener for Search Input (Autocomplete Logic) ---
  if (productSearch && brandSelect && suggestionsList && searchHint && productSelectElement) { // Added productSelectElement check
      productSearch.addEventListener("input", (e) => {
          const searchTerm = e.target.value.trim().toLowerCase();
          const selectedBrand = brandSelect.value;
          searchHint.textContent = "";

          if (!selectedBrand) { hideSuggestionsImmediately(); return; }
          if (searchTerm.length < 1) { hideSuggestionsImmediately(); return; }

          const brandProducts = PRODUCTS.filter(p => p && p.brand === selectedBrand);
          const matchedProducts = brandProducts.filter(p => p && (p.name || '').toLowerCase().includes(searchTerm));

          console.log(`Search term "${searchTerm}" matched ${matchedProducts.length} products for suggestions.`);
          showSuggestions(matchedProducts);
          if (matchedProducts.length === 0) searchHint.textContent = "لم يتم العثور على تطابق.";
      });

      productSearch.addEventListener('blur', hideSuggestionsWithDelay);

      // Handle Keyboard Navigation (ArrowDown, ArrowUp, Enter, Escape)
      productSearch.addEventListener("keydown", (e) => {
          const suggestions = suggestionsList.querySelectorAll('div');
          const isListVisible = suggestionsList.style.display === 'block' && suggestions.length > 0;
          const mainSelect = document.getElementById('productSelect'); // Get main dropdown

          let currentSuggestionIndex = -1;
          if (isListVisible) {
              suggestions.forEach((item, index) => {
                  if (item.classList.contains('suggestion-highlight')) {
                      currentSuggestionIndex = index;
                  }
              });
          }

          switch (e.key) {
              case 'ArrowDown':
                  e.preventDefault(); // Prevent cursor movement / page scroll
                  if (isListVisible) {
                      // Navigate suggestions list
                      let nextIndex = currentSuggestionIndex < suggestions.length - 1 ? currentSuggestionIndex + 1 : 0;
                      highlightSuggestion(nextIndex);
                  } else if (mainSelect && mainSelect.options.length > 1) { // More than just "-- اختر الصنف --"
                      // Navigate main dropdown
                      let currentMainIndex = mainSelect.selectedIndex;
                      let nextMainIndex = currentMainIndex + 1;
                      if (nextMainIndex >= mainSelect.options.length) {
                          nextMainIndex = mainSelect.options[0].value ? 0 : 1; // Start from first real option
                      }
                      mainSelect.selectedIndex = nextMainIndex;
                      // Update search input to match selected dropdown item
                      productSearch.value = mainSelect.options[nextMainIndex]?.text || '';
                      productSearch.dispatchEvent(new Event('input')); // Trigger input event to maybe show suggestions
                  }
                  break;

              case 'ArrowUp':
                  e.preventDefault(); // Prevent cursor movement / page scroll
                  if (isListVisible) {
                      // Navigate suggestions list
                      let prevIndex = currentSuggestionIndex > 0 ? currentSuggestionIndex - 1 : suggestions.length - 1;
                      highlightSuggestion(prevIndex);
                  } else if (mainSelect && mainSelect.options.length > 1) {
                      // Navigate main dropdown
                      let currentMainIndex = mainSelect.selectedIndex;
                      let prevMainIndex = currentMainIndex - 1;
                      if (prevMainIndex < (mainSelect.options[0].value ? 0 : 1)) {
                          prevMainIndex = mainSelect.options.length - 1; // Go to last option
                      }
                      mainSelect.selectedIndex = prevMainIndex;
                      // Update search input to match selected dropdown item
                      productSearch.value = mainSelect.options[prevMainIndex]?.text || '';
                      productSearch.dispatchEvent(new Event('input')); // Trigger input event
                  }
                  break;

              case 'Enter':
                  e.preventDefault();
                  if (isListVisible && currentSuggestionIndex !== -1) {
                      // Select highlighted suggestion
                      suggestions[currentSuggestionIndex].dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
                  } else if (mainSelect && mainSelect.value) {
                      // If NO suggestion is highlighted OR suggestions are hidden, add selected dropdown item
                      document.getElementById('btnAdd')?.click();
                  }
                  break;

              case 'Escape':
                  e.preventDefault();
                  if (isListVisible) {
                      hideSuggestionsImmediately();
                  }
                  break;
          }
      });

      // Helper function to highlight a suggestion by index AND update main select
      function highlightSuggestion(index) {
          const suggestions = suggestionsList.querySelectorAll('div');
          const mainSelect = document.getElementById('productSelect');

          suggestions.forEach((item, i) => {
              item.classList.remove('suggestion-highlight');
              if (i === index) {
                  item.classList.add('suggestion-highlight');
                  item.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                  const productIdToSelect = item.dataset.productId;
                  if (mainSelect && productIdToSelect) {
                      mainSelect.value = productIdToSelect;
                      console.log(`Main select updated via keyboard: ${productIdToSelect}`);
                  }
              }
          });
      }


      console.log("✅ Product search (autocomplete + keyboard nav) listener attached.");
  } else {
       console.error("❌ Missing elements for product search listener.");
  }

  console.log("🧩 uiManager.js event listeners setup complete.");
}); // End DOMContentLoaded


// ======= عرض محتوى السلة (المعاينة) =======
window.renderCartPreview = function() {
    const body = document.getElementById("cartTableBody");
    const totalBox = document.getElementById("totalBox");
    const empty = document.getElementById("emptyState");
    const invoice = document.getElementById("invoiceContent");
    const btnPrint = document.getElementById("btnPrint");
    const previewMeta = document.getElementById('preview-meta');

    if (!body || !totalBox || !empty || !invoice || !btnPrint || !previewMeta) {
        console.error("⚠️ Missing one or more critical cart preview elements for renderCartPreview.");
        return;
    }
     if (typeof CART === 'undefined' || !Array.isArray(CART)) {
         console.warn("⚠️ CART array not available for rendering preview.");
         CART = [];
     }

    body.innerHTML = ""; // Clear previous content

    if (CART.length === 0) {
      empty.style.display = "flex";
      invoice.style.display = "none";
      totalBox.textContent = (typeof maskAmount === 'function' ? maskAmount(0) : "0 ج.م"); // Use maskAmount or fallback
      btnPrint.style.display = "none";
      previewMeta.textContent = "لا توجد أصناف مضافة";
      return;
    }

    // Cart has items
    empty.style.display = "none";
    invoice.style.display = "flex"; // Show the table container
    btnPrint.style.display = "inline-block"; // Show print button

    let total = 0;
    CART.forEach((item, idx) => {
      const price = Number(item.price) || 0;
      const qty = Number(item.qty) || 0;
      const itemTotal = price * qty;
      total += itemTotal;
      const brand = item.brand || '-';
      const id = item.id || '-';
      const name = item.name || '-';

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${idx + 1}</td>
        <td>${brand}</td>
        <td>${id}</td>
        <td style="text-align: right;">${name}</td>
        <td>${qty}</td>
        <td><button class="btn-sm danger" data-idx="${idx}" title="حذف الصنف">🗑️</button></td>`;
      body.appendChild(tr);
    });

    // Display total (masked or formatted)
    const maskedTotalDisplay = (typeof maskAmount === 'function' ? maskAmount(total) : fmtCurrency(total)); // Use maskAmount or fallback
    totalBox.textContent = maskedTotalDisplay;
    previewMeta.textContent = `${CART.length} أصناف | ${maskedTotalDisplay}`;

    // Add event listeners to delete buttons
    body.querySelectorAll(".btn-sm.danger").forEach(btn =>
      btn.addEventListener("click", e => {
        // Use currentTarget to ensure we get the button element
        const button = e.currentTarget;
        const idx = parseInt(button.dataset.idx, 10);
        if (!isNaN(idx) && idx >= 0 && idx < CART.length) {
            console.log(`Removing item at index ${idx}:`, CART[idx]);
            CART.splice(idx, 1);
            if (typeof saveCartToLocal === 'function') saveCartToLocal(); else console.error("saveCartToLocal not defined");
            renderCartPreview(); // Re-render the cart
            if (typeof setStatusHint === 'function') setStatusHint('🗑️ تم حذف الصنف.', 'success'); else console.warn("setStatusHint not defined");
        } else {
            console.error(`Invalid index ${idx} for deletion.`);
        }
      })
    );
}; // End renderCartPreview