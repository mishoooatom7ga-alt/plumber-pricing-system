// public/js/cartHandler.js (تصحيح قوس الإغلاق)
console.log("✅ cartHandler.js loaded");

function addToCart() {
  const productSelect = document.getElementById("productSelect");
  const qtyInput = document.getElementById("qty");

  if (!productSelect || !qtyInput) {
    console.error("⚠️ Add to cart elements (#productSelect or #qty) not found!");
    setStatusHint("خطأ: لم يتم العثور على عناصر الإضافة!", "error");
    return;
  }

  const productId = productSelect.value;
  if (!productId) {
      setStatusHint("⚠️ يرجى اختيار صنف أولاً.", "error");
      return;
  }
   // Ensure PRODUCTS is available and is an array
   if (typeof PRODUCTS === 'undefined' || !Array.isArray(PRODUCTS)) {
       console.error("❌ PRODUCTS array is not available or not an array for addToCart.");
       setStatusHint("خطأ: بيانات المنتجات غير متاحة.", "error");
       return;
   }
   const selectedProduct = PRODUCTS.find(p => p && p.id === productId); // Added check for p
   if (!selectedProduct) {
       console.error(`❌ Product with ID "${productId}" not found in PRODUCTS array.`);
       setStatusHint(`خطأ: المنتج المختار غير موجود (${productId})`, "error");
       return;
   }

  const qty = parseInt(qtyInput.value, 10);
   if (isNaN(qty) || qty <= 0) {
       setStatusHint("⚠️ يرجى إدخال كمية صحيحة (أكبر من صفر).", "error");
       qtyInput.value = "1"; qtyInput.focus();
       return;
   }

   // Ensure CART is initialized
   if (typeof CART === 'undefined' || !Array.isArray(CART)) {
       console.warn("⚠️ CART array was undefined, initializing.");
       CART = [];
   }

  const existing = CART.find(p => p.id === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    // Ensure price is added correctly
    const priceToAdd = selectedProduct.price !== undefined ? selectedProduct.price : 0; // Default to 0 if price missing
    CART.push({
      id: selectedProduct.id, name: selectedProduct.name,
      brand: selectedProduct.brand, price: priceToAdd, qty: qty // Use priceToAdd
    });
  }

  // Ensure helper functions exist before calling
  if (typeof saveCartToLocal === 'function') saveCartToLocal(); else console.error("❌ saveCartToLocal is not defined");
  if (typeof renderCartPreview === 'function') renderCartPreview(); else console.error("❌ renderCartPreview is not defined");
  if (typeof setStatusHint === 'function') setStatusHint(`✅ تمت إضافة ${selectedProduct.name} (x${qty})`, "success"); else console.warn("setStatusHint not defined");

  console.log(`➕ Item added/updated: ${selectedProduct.name} (Qty: ${qty})`);

  qtyInput.value = "1";
  try { productSelect.focus(); } catch(e) {} // Focus product select after adding
}

function clearCart() {
  if (typeof Swal !== 'undefined') {
    Swal.fire({
      title: 'مسح السلة', text: 'هل أنت متأكد أنك تريد مسح السلة بالكامل؟',
      icon: 'warning', showCancelButton: true, confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6', confirmButtonText: 'نعم، امسحها!', cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        CART = [];
        if (typeof saveCartToLocal === 'function') saveCartToLocal();
        if (typeof renderCartPreview === 'function') renderCartPreview();
        if (typeof setStatusHint === 'function') setStatusHint("🗑️ تم مسح السلة بنجاح.", "success");
        console.log("🗑️ Cart cleared.");
        Swal.fire('تم المسح!','تم إفراغ سلة الأصناف.','success')
      }
    });
  } else {
    if (confirm("هل أنت متأكد أنك تريد مسح السلة بالكامل؟")) {
      CART = [];
      if (typeof saveCartToLocal === 'function') saveCartToLocal();
      if (typeof renderCartPreview === 'function') renderCartPreview();
      if (typeof setStatusHint === 'function') setStatusHint("🗑️ تم مسح السلة", "success");
      console.log("🗑️ Cart cleared (using confirm).");
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const btnAdd = document.getElementById("btnAdd");
  const btnClear = document.getElementById("btnClear");
  const qtyInput = document.getElementById("qty");

  if (btnAdd) { btnAdd.addEventListener("click", (e) => { e.preventDefault(); addToCart(); }); }
  else { console.error("❌ Button #btnAdd not found!"); }

  if (btnClear) { btnClear.addEventListener("click", (e) => { e.preventDefault(); clearCart(); }); }
  else { console.error("❌ Button #btnClear not found!"); }

  if (qtyInput && btnAdd) {
    qtyInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); btnAdd.click(); }
    });
  } else {
      if (!qtyInput) console.error("❌ Input #qty not found for Enter key binding!");
      // btnAdd existence already checked above
  }
  console.log("🧩 cartHandler.js event listeners attached.");
}); // <-- قوس الإغلاق الصحيح لـ DOMContentLoaded

// --- 🔽 حذف قوس الإغلاق الزائد 🔽 ---
// } // <-- هذا القوس كان زائدًا
// --- 🔼 ---