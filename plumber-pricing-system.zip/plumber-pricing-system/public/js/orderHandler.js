console.log("✅ orderHandler.js loaded (defines buildOrderData)");

// بناء بيانات الطلب للحفظ المحلي
// public/js/orderHandler.js
window.buildOrderData = function() {
  const nameInput = document.getElementById("customerName");
  const placeInput = document.getElementById("customerPlace"); // Get place input
  const techInput = document.getElementById("technicianName"); // 🔽 (إضافة: جلب حقل المندوب)

  const name = nameInput ? nameInput.value.trim() : "";
  const place = placeInput ? placeInput.value.trim() : ""; // Get place value
  
  // 🔽 (إضافة: قراءة قيمة المندوب)
  // إذا كان الحقل موجودًا (في صفحة الفني)، احصل على قيمته
  // إذا لم يكن موجودًا (في صفحة التاجر)، ستكون القيمة undefined
  const technician = techInput ? techInput.value.trim() : undefined;
  // 🔼 (نهاية الإضافة)


   if (typeof CART === 'undefined' || !Array.isArray(CART)) {
      console.warn("⚠️ CART array not available for buildOrderData.");
      CART = [];
  }

  const total = CART.reduce((sum, item) => {
      const price = Number(item.price) || 0;
      const qty = Number(item.qty) || 0;
      return sum + (price * qty);
  }, 0);

  return {
    id: CURRENT_ORDER_ID || randId(), 
    client: name, 
    place: place, 
    items: CART,
    total: total,
    date: new Date().toLocaleString("ar-EG", { dateStyle: 'short', timeStyle: 'short' }),
    technicianName: technician // 🔽 (إضافة: إرسال اسم المندوب للسيرفر)
  };
}

// ======================================
// إرسال الطلب إلى السيرفر (-> تليجرام)
// ======================================
window.sendOrder = async function() {
  console.log("🚀 attempting to send order...");

  // 1. تحقق من السلة
  if (typeof CART === 'undefined' || CART.length === 0) {
    if (typeof Swal !== 'undefined') Swal.fire('السلة فارغة', 'لا يمكنك إرسال طلب فارغ، أضف أصناف أولاً.', 'warning');
    else alert('السلة فارغة!');
    return;
  }

  // 2. بناء بيانات الطلب
  const order = buildOrderData();

  // 3. (مهم) التحقق من اسم العميل
  if (!order.client) {
     if (typeof Swal !== 'undefined') {
        Swal.fire({
          title: 'بيانات ناقصة',
          text: 'يجب إدخال "اسم العميل (ثلاثي)" قبل إرسال الطلب للمعرض.',
          icon: 'warning',
          confirmButtonText: 'حسنًا'
        });
     } else {
       alert('يجب إدخال اسم العميل أولاً.');
     }
     try { document.getElementById("customerName")?.focus(); } catch(e){}
     return;
  }

  // --- 🔽 (الإضافة الجديدة هنا) ---
  // 4. (مهم) التحقق من المكان
  if (!order.place) {
     if (typeof Swal !== 'undefined') {
        Swal.fire({
          title: 'بيانات ناقصة',
          text: '⚠️ من فضلك أدخل مكان العمل قبل إرسال الطلب.', // الرسالة المطلوبة
          icon: 'warning',
          confirmButtonText: 'حسنًا'
        });
     } else {
       alert('⚠️ من فضلك أدخل مكان العمل قبل إرسال الطلب.');
     }
     try { document.getElementById("customerPlace")?.focus(); } catch(e){} // محاولة التركيز على حقل المكان
     return; // إيقاف الإرسال
  }
  // --- 🔼 (نهاية الإضافة) ---

  // 5. إظهار مؤشر التحميل (كان رقم 4)
  if (typeof Swal !== 'undefined') {
    Swal.fire({
      title: 'جاري إرسال الطلب...',
      text: 'لحظات من فضلك، يتم إرسال الفاتورة للمعرض.',
      allowOutsideClick: false,
      didOpen: () => { Swal.showLoading(); }
    });
  } else {
    console.log("جاري إرسال الطلب...");
  }

  // 6. إرسال الطلب للسيرفر (كان رقم 5)
  try {
    const response = await fetch("/api/submit-order", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });

    const result = await response.json();

    if (response.ok && result.success) {
      if (typeof Swal !== 'undefined') {
        Swal.fire({
          icon: 'success',
          title: 'تم الإرسال بنجاح!',
          text: result.message || 'تم إرسال الطلب إلى المعرض.',
          timer: 2500,
          showConfirmButton: false
        });
      }
      console.log(`✅ Order ${order.id} sent successfully.`);

      CURRENT_ORDER_ID = randId();
      saveCartToLocal(); // لحفظ الـ ID الجديد

    } else {
      throw new Error(result.message || "فشل غير معروف من السيرفر");
    }

  } catch (err) {
    console.error("❌ فشل إرسال الطلب للسيرفر:", err);
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: 'error',
        title: 'خطأ في الإرسال',
        text: `تعذر إرسال الطلب: ${err.message}`
      });
    }
  }
}

console.log("📦 orderHandler.js definitions ready.");