// quick-mode.js - Logic for Quick Mode Overlay

// Ensure functions from main scope are available if needed
// Assuming PRODUCTS, CART, saveCartToLocal, renderCartPreview, fmtCurrency are global or attached to window
console.log("⚡ Quick Mode JS Loading...");

(function() { // IIFE to encapsulate scope
    'use strict';

    // DOM Elements (Ensure these IDs exist in the embedded HTML)
    // Note: These might be null initially if script runs before HTML is parsed
    // It's safer to get them inside functions or check existence before use.
    // However, initQuickMode being called after DOMContentLoaded should mitigate this.
    const backdrop = document.getElementById('quickModeBackdrop');
    const panel = document.getElementById('quickModePanel');
    const closeBtn = document.getElementById('qmCloseBtn');
    const brandSelect = document.getElementById('qmBrandSelect');
    const productSearch = document.getElementById('qmProductSearch');
    const productList = document.getElementById('qmProductList');
    const previewList = document.getElementById('qmQuickPreviewList');
    const previewPlaceholder = document.getElementById('qmPreviewPlaceholder');
    const itemCountSpan = document.getElementById('qmItemCount');
    const saveBtn = document.getElementById('qmSaveBtn');
    const clearPreviewBtn = document.getElementById('qmClearPreviewBtn');
    const statusDisplay = document.getElementById('qmStatus');

    const STORAGE_KEY = 'quickModeItems';
    let quickModeItems = []; // Local state for items in quick preview
    let isVisible = false;

    // --- Utility Functions ---
    function setStatus(message = '', type = 'info') {
        const statusDisplayElem = document.getElementById('qmStatus'); // Re-find element
        if (!statusDisplayElem) return;
        statusDisplayElem.textContent = message;
        statusDisplayElem.className = 'qm-status-message'; // Reset
        if (type === 'error') statusDisplayElem.classList.add('error');
        if (type === 'success') statusDisplayElem.classList.add('success');
    }

    // --- Local Storage Handling ---
    function saveQuickItemsToStorage() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(quickModeItems));
        } catch (e) {
            console.error("Error saving Quick Mode items to localStorage:", e);
            setStatus("خطأ في حفظ البيانات المؤقتة", "error");
        }
    }

    function loadQuickItemsFromStorage() {
        try {
            const storedItems = localStorage.getItem(STORAGE_KEY);
            if (storedItems) {
                quickModeItems = JSON.parse(storedItems);
                if (!Array.isArray(quickModeItems)) quickModeItems = [];
            } else {
                quickModeItems = [];
            }
        } catch (e) {
            console.error("Error loading Quick Mode items from localStorage:", e);
            quickModeItems = [];
            setStatus("خطأ في تحميل البيانات المؤقتة", "error");
        }
    }

    // --- UI Rendering ---
    function populateQmBrands() {
        const brandSelectElem = document.getElementById('qmBrandSelect');
        if (!brandSelectElem) return;
        if (typeof window.PRODUCTS === 'undefined' || !Array.isArray(window.PRODUCTS)) {
            console.error("Main PRODUCTS array not found for Quick Mode brands.");
            return;
        }
        const sections = Array.from(new Set(window.PRODUCTS.map(p => p && p.brand ? p.brand : "عام").filter(Boolean))).sort();
        brandSelectElem.innerHTML = '<option value="">-- اختر القسم أولاً --</option>';
        sections.forEach(s => {
            const opt = document.createElement("option");
            opt.value = s;
            opt.textContent = s;
            brandSelectElem.appendChild(opt);
        });
        console.log("QM: Brands populated.");
    }

    function populateQmProductList() {
        const productListElem = document.getElementById('qmProductList');
        const brandSelectElem = document.getElementById('qmBrandSelect');
        const productSearchInput = document.getElementById('qmProductSearch');
        if (!productListElem || !brandSelectElem || !productSearchInput) return;

        const selectedBrand = brandSelectElem.value;
        const searchTerm = productSearchInput.value.trim().toLowerCase();
        productListElem.innerHTML = '';

        if (!selectedBrand) {
            productListElem.innerHTML = '<li class="qm-list-placeholder">اختر قسمًا لعرض الأصناف...</li>';
            productSearchInput.disabled = true;
            return;
        }
        productSearchInput.disabled = false;

        if (typeof window.PRODUCTS === 'undefined') {
             productListElem.innerHTML = '<li class="qm-list-placeholder error">خطأ: بيانات المنتجات غير متاحة.</li>';
             return;
        }

        const quickModeItemIds = new Set(quickModeItems.map(item => item.id));
        let availableProducts = window.PRODUCTS.filter(p => p && p.brand === selectedBrand && !quickModeItemIds.has(p.id));

        if (searchTerm.length > 0) {
            availableProducts = availableProducts.filter(p => p && p.name && p.name.toLowerCase().includes(searchTerm));
        }

        if (availableProducts.length === 0) {
            productListElem.innerHTML = `<li class="qm-list-placeholder">${searchTerm.length > 0 ? 'لا توجد نتائج مطابقة للبحث.' : 'لا توجد أصناف متاحة بهذا القسم.'}</li>`;
        } else {
            availableProducts.forEach(product => {
                const li = document.createElement('li');
                li.textContent = product.name;
                li.dataset.productId = product.id;
                li.addEventListener('click', () => handleProductSelection(product.id));
                productListElem.appendChild(li);
            });
        }
         console.log(`QM: Product list updated for brand "${selectedBrand}", search "${searchTerm}". Found ${availableProducts.length}`);
    }

    function renderQmQuickPreview() {
        const previewListElem = document.getElementById('qmQuickPreviewList');
        const itemCountSpanElem = document.getElementById('qmItemCount');
        const saveBtnElem = document.getElementById('qmSaveBtn');
        const clearPreviewBtnElem = document.getElementById('qmClearPreviewBtn');
        const previewPlaceholderElem = document.getElementById('qmPreviewPlaceholder');

        if (!previewListElem || !itemCountSpanElem || !saveBtnElem || !clearPreviewBtnElem || !previewPlaceholderElem) {
            console.error("QM: One or more preview elements are missing.");
            return;
        }
        previewListElem.innerHTML = '';

        if (quickModeItems.length === 0) {
            previewPlaceholderElem.style.display = 'block';
            itemCountSpanElem.textContent = '0';
            saveBtnElem.disabled = true;
            clearPreviewBtnElem.style.display = 'none';
            return;
        }

        previewPlaceholderElem.style.display = 'none';
        itemCountSpanElem.textContent = quickModeItems.length.toString();
        saveBtnElem.disabled = false;
        clearPreviewBtnElem.style.display = 'block';

        quickModeItems.forEach((item, index) => {
            const li = document.createElement('li');
            li.dataset.productId = item.id;
            const nameSpan = document.createElement('span'); nameSpan.className = 'qm-item-name'; nameSpan.textContent = item.name; nameSpan.title = item.name;
            const controlsDiv = document.createElement('div'); controlsDiv.className = 'qm-item-controls';
            const qtyInput = document.createElement('input'); qtyInput.type = 'number'; qtyInput.className = 'qm-item-qty'; qtyInput.value = item.qty; qtyInput.min = '1'; qtyInput.dataset.productId = item.id; qtyInput.setAttribute('aria-label', `كمية ${item.name}`);
            qtyInput.addEventListener('change', handleQuantityChange); qtyInput.addEventListener('blur', handleQuantityChange); qtyInput.addEventListener('keydown', (e) => handleQuantityEnter(e, index));
            const deleteBtn = document.createElement('button'); deleteBtn.className = 'qm-delete-item-btn'; deleteBtn.innerHTML = '🗑️'; deleteBtn.dataset.productId = item.id; deleteBtn.setAttribute('aria-label', `حذف ${item.name}`); deleteBtn.addEventListener('click', handleDeleteItem);
            controlsDiv.appendChild(qtyInput); controlsDiv.appendChild(deleteBtn);
            li.appendChild(nameSpan); li.appendChild(controlsDiv);
            previewListElem.appendChild(li);
        });
         console.log("QM: Preview list rendered.");
    }

    // --- Event Handlers ---
    function handleBrandChange() {
        const productSearchInput = document.getElementById('qmProductSearch');
        if (productSearchInput) { productSearchInput.value = ''; }
        else { console.error("QM: #qmProductSearch element not found in handleBrandChange."); }
        populateQmProductList();
    }

    function handleSearchInput() { populateQmProductList(); }

    function handleProductSelection(productId) {
        if (typeof window.PRODUCTS === 'undefined') return;
        const product = window.PRODUCTS.find(p => p && p.id === productId);
        if (!product) { console.error(`QM: Product with ID ${productId} not found.`); return; }
        if (!quickModeItems.some(item => item.id === productId)) {
            quickModeItems.push({ id: product.id, name: product.name, price: product.price, brand: product.brand, qty: 1 });
            saveQuickItemsToStorage(); populateQmProductList(); renderQmQuickPreview();
            setStatus(`✅ تم إضافة: ${product.name}`, 'success');
            const searchInput = document.getElementById('qmProductSearch');
            if (searchInput) searchInput.focus();
        } else { setStatus(`⚠️ الصنف موجود بالفعل في القائمة`, 'error'); }
    }

    function handleQuantityChange(event) {
        const input = event.target; const productId = input.dataset.productId; let newQty = parseInt(input.value, 10);
        if (isNaN(newQty) || newQty < 1) { newQty = 1; input.value = '1'; }
        const itemIndex = quickModeItems.findIndex(item => item.id === productId);
        if (itemIndex !== -1 && quickModeItems[itemIndex].qty !== newQty) {
            quickModeItems[itemIndex].qty = newQty; saveQuickItemsToStorage();
            console.log(`QM: Quantity updated for ${productId} to ${newQty}`);
        }
    }

     function handleQuantityEnter(event, currentIndex) {
        if (event.key === 'Enter') {
            event.preventDefault();
            const previewListElem = document.getElementById('qmQuickPreviewList'); // Re-find
            const allQtyInputs = previewListElem?.querySelectorAll('.qm-item-qty');
            const saveBtnElem = document.getElementById('qmSaveBtn'); // Re-find
            if (!allQtyInputs) return;
            const nextIndex = currentIndex + 1;
            if (nextIndex < allQtyInputs.length) { allQtyInputs[nextIndex].focus(); allQtyInputs[nextIndex].select(); }
            else { if(saveBtnElem) saveBtnElem.focus(); }
        }
    }

    function handleDeleteItem(event) {
        const button = event.currentTarget; const productId = button.dataset.productId;
        const itemIndex = quickModeItems.findIndex(item => item.id === productId);
        if (itemIndex !== -1) {
            const removedItemName = quickModeItems[itemIndex].name;
            quickModeItems.splice(itemIndex, 1); saveQuickItemsToStorage();
            populateQmProductList(); renderQmQuickPreview();
            setStatus(`🗑️ تم حذف: ${removedItemName}`, 'info');
        }
    }

     function handleClearPreview() {
        if (quickModeItems.length > 0 && confirm("هل أنت متأكد من مسح جميع الأصناف في قائمة المعاينة السريعة؟")) {
            clearQuickModeInternal(); setStatus('🧹 تم مسح قائمة المعاينة.', 'info');
        }
    }

    function handleSave() {
        if (quickModeItems.length === 0) return;
        const saveBtnElem = document.getElementById('qmSaveBtn'); // Re-find

        console.log("QM: Saving items to main cart...");
        setStatus("جاري الحفظ...", "info");
        if (saveBtnElem) saveBtnElem.disabled = true;

        if (typeof window.CART === 'undefined' || typeof window.saveCartToLocal === 'undefined' || typeof window.renderCartPreview === 'undefined') {
             console.error("Main cart functions (CART, saveCartToLocal, renderCartPreview) not found!");
             setStatus("خطأ فادح: لا يمكن الوصول لوظائف السلة الرئيسية.", "error");
             if (saveBtnElem) saveBtnElem.disabled = false;
             return;
        }

        quickModeItems.forEach(qmItem => {
            const existingCartItem = window.CART.find(cartItem => cartItem.id === qmItem.id);
            if (existingCartItem) { existingCartItem.qty += qmItem.qty; }
            else { window.CART.push({ ...qmItem }); }
        });

        window.saveCartToLocal(); window.renderCartPreview();
        clearQuickModeInternal(); hideQuickMode();
        if (typeof window.setStatusHint === 'function') { window.setStatusHint('✅ تم إضافة أصناف Quick Mode للسلة الرئيسية.', 'success'); }
        console.log("QM: Items saved, Quick Mode closed.");
        if (saveBtnElem) saveBtnElem.disabled = false;
    }

    function clearQuickModeInternal() {
         quickModeItems = []; saveQuickItemsToStorage();
         populateQmProductList(); renderQmQuickPreview();
    }


    // --- Show/Hide Quick Mode ---
    window.showQuickMode = function() {
        const backdropElem = document.getElementById('quickModeBackdrop');
        const panelElem = document.getElementById('quickModePanel');
        const brandSelectElem = document.getElementById('qmBrandSelect');

        if (!backdropElem || !panelElem) {
            console.error("🚨 CRITICAL: Quick Mode backdrop or panel element not found when trying to show.");
            if (typeof Swal !== 'undefined') Swal.fire('خطأ', 'فشلت تهيئة واجهة Quick Mode.', 'error');
            return;
        }
        if (isVisible) return;

        console.log("QM: Showing Quick Mode...");
        setStatus(''); loadQuickItemsFromStorage(); populateQmBrands(); handleBrandChange(); renderQmQuickPreview();
        backdropElem.classList.add('qm-visible'); panelElem.classList.add('qm-visible');
        isVisible = true;
        if (brandSelectElem) { brandSelectElem.focus(); }
        else { console.warn("QM: #qmBrandSelect not found for focusing."); }
    }

    // --- Definition for hideQuickMode --- <<< Correctly placed OUTSIDE showQuickMode
    window.hideQuickMode = function() {
        const backdropElem = document.getElementById('quickModeBackdrop');
        const panelElem = document.getElementById('quickModePanel');
        if (!isVisible || !backdropElem || !panelElem) return;
        console.log("QM: Hiding Quick Mode...");
        backdropElem.classList.remove('qm-visible');
        panelElem.classList.remove('qm-visible');
        isVisible = false;
    }
    // --- End Definition ---


    // --- Initial Setup & Event Listeners ---
    function initQuickModeListeners() {
        const backdropElem = document.getElementById('quickModeBackdrop');
        const panelElem = document.getElementById('quickModePanel');
        const closeBtnElem = document.getElementById('qmCloseBtn');
        const brandSelectElem = document.getElementById('qmBrandSelect');
        const productSearchElem = document.getElementById('qmProductSearch');
        const saveBtnElem = document.getElementById('qmSaveBtn');
        const clearPreviewBtnElem = document.getElementById('qmClearPreviewBtn');

        if (!panelElem || !closeBtnElem || !brandSelectElem || !productSearchElem || !saveBtnElem || !clearPreviewBtnElem || !backdropElem) {
             console.error("🚨 CRITICAL: Could not find all necessary Quick Mode elements during initialization. Aborting QM setup.");
             const qmButton = document.getElementById('quickModeToggleBtn');
             if(qmButton) { qmButton.disabled = true; qmButton.title = "Quick Mode failed to initialize"; }
             return;
        }

        closeBtnElem.addEventListener('click', hideQuickMode);
        backdropElem.addEventListener('click', hideQuickMode);
        brandSelectElem.addEventListener('change', handleBrandChange);
        productSearchElem.addEventListener('input', handleSearchInput);
        saveBtnElem.addEventListener('click', handleSave);
        clearPreviewBtnElem.addEventListener('click', handleClearPreview);
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && isVisible) { hideQuickMode(); } });

        console.log("QM: Event listeners attached successfully.");
    }

    // Expose the initialization function globally
    window.initQuickMode = initQuickModeListeners;

})(); // End IIFE

console.log("⚡ Quick Mode JS Ready.");