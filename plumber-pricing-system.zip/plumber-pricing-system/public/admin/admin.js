// admin.js - Logic for the Admin User Management Panel
document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Panel JS Loaded");

    // DOM Elements
    const userTableBody = document.querySelector('#usersTable tbody');
    const addUserBtn = document.getElementById('addUserBtn');
    const userModal = document.getElementById('userModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const cancelModalBtn = document.getElementById('cancelModalBtn');
    const userForm = document.getElementById('userForm');
    const modalTitle = document.getElementById('modalTitle');
    const usernameInput = document.getElementById('username');
    const fullnameInput = document.getElementById('fullname');
    const passwordInput = document.getElementById('password');
    const passwordHelp = document.getElementById('passwordHelp');
    const roleSelect = document.getElementById('role');
    const statusSelect = document.getElementById('status');
    const saveUserBtn = document.getElementById('saveUserBtn');
    const editUsernameField = document.getElementById('editUsername'); // Hidden field
    const modalErrorDisplay = document.getElementById('modalErrorDisplay');
    const mainErrorDisplay = document.getElementById('errorDisplay');

    let currentUsers = []; // To store fetched users locally

    // --- API Helper ---
    async function apiRequest(endpoint, method = 'GET', body = null) {
        const options = {
            method,
            headers: {},
        };
        if (body) {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(body);
        }
        try {
            const response = await fetch(endpoint, options);
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || `HTTP error! Status: ${response.status}`);
            }
            return data;
        } catch (error) {
            console.error(`API request failed: ${method} ${endpoint}`, error);
            throw error; // Re-throw to be caught by caller
        }
    }

    // --- Modal Handling ---
    function showModal(mode = 'add', userData = null) {
        modalErrorDisplay.textContent = ''; // Clear previous errors
        userForm.reset(); // Reset form fields
        editUsernameField.value = ''; // Clear hidden username field

        if (mode === 'add') {
            modalTitle.textContent = 'إضافة مستخدم جديد';
            usernameInput.readOnly = false;
            usernameInput.disabled = false; // Ensure it's enabled
            passwordInput.required = true; // Password required for new user
            passwordHelp.style.display = 'none'; // Hide the "leave blank" message
            saveUserBtn.textContent = 'إضافة مستخدم';
        } else if (mode === 'edit' && userData) {
            modalTitle.textContent = 'تعديل بيانات المستخدم';
            usernameInput.value = userData.username;
            usernameInput.readOnly = true; // Don't allow username change
            usernameInput.disabled = true; // Visually indicate it's disabled
            fullnameInput.value = userData.fullname || '';
            roleSelect.value = userData.role || 'plumber'; // Default to plumber if missing
            statusSelect.value = userData.status || 'inactive';
            passwordInput.required = false; // Password not required for editing
            passwordHelp.style.display = 'block'; // Show the "leave blank" message
            editUsernameField.value = userData.username; // Store username for PUT request
            saveUserBtn.textContent = 'حفظ التعديلات';
        } else {
            console.error("Invalid modal mode or missing user data for edit.");
            return;
        }
        userModal.style.display = 'flex'; // Show modal using flex for centering
    }

    function hideModal() {
        userModal.style.display = 'none';
        userForm.reset();
        modalErrorDisplay.textContent = '';
        editUsernameField.value = '';
    }

    // --- Rendering Functions ---
    function renderUserTable(users) {
        userTableBody.innerHTML = ''; // Clear existing rows
        mainErrorDisplay.textContent = ''; // Clear main errors

        if (!users || users.length === 0) {
            userTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">لا يوجد مستخدمون لعرضهم.</td></tr>';
            return;
        }

        users.forEach(user => {
            const tr = document.createElement('tr');
            tr.dataset.username = user.username; // Store username on the row

            // Status Badge
            const statusBadgeClass = user.status === 'active' ? 'status-active' : 'status-inactive';
            const statusText = user.status === 'active' ? 'نشط' : 'غير نشط';

            tr.innerHTML = `
                <td>${user.username || 'N/A'}</td>
                <td>${user.fullname || 'N/A'}</td>
                <td>${user.role || 'N/A'}</td>
                <td><span class="status-badge ${statusBadgeClass}">${statusText}</span></td>
                <td class="actions-cell">
                    <button class="btn btn-warning edit-btn" data-username="${user.username}" title="تعديل">✏️</button>
                    <button class="btn btn-danger delete-btn" data-username="${user.username}" title="حذف">🗑️</button>
                </td>
            `;
            userTableBody.appendChild(tr);
        });

        // Add event listeners after rendering rows
        attachActionListeners();
    }

    // --- Fetch and Render Initial Data ---
    async function fetchUsersAndRender() {
        userTableBody.innerHTML = '<tr><td colspan="5" class="loading-state">جاري تحميل المستخدمين...</td></tr>';
        mainErrorDisplay.textContent = '';
        try {
            const data = await apiRequest('/api/users');
            currentUsers = data.users || []; // Store users locally
            renderUserTable(currentUsers);
        } catch (error) {
            mainErrorDisplay.textContent = `فشل تحميل المستخدمين: ${error.message}`;
            userTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">حدث خطأ أثناء تحميل المستخدمين.</td></tr>';
        }
    }

    // --- Event Handlers ---
    async function handleSaveUser(event) {
        event.preventDefault();
        modalErrorDisplay.textContent = '';
        saveUserBtn.disabled = true;
        saveUserBtn.textContent = 'جاري الحفظ...';

        const formData = new FormData(userForm);
        const data = Object.fromEntries(formData.entries());
        const isEditMode = !!editUsernameField.value;
        const username = isEditMode ? editUsernameField.value : data.username;

        // Clean up data: remove empty password for edits
        if (isEditMode && (!data.password || data.password.trim() === '')) {
            delete data.password;
        }
        // Remove the hidden field value if present
        delete data.editUsername;
        // Username is part of the URL in edit mode, not body
        if (isEditMode) {
             delete data.username;
        }


        const method = isEditMode ? 'PUT' : 'POST';
        const endpoint = isEditMode ? `/api/users/${encodeURIComponent(username)}` : '/api/users';

        try {
            const result = await apiRequest(endpoint, method, data);
            console.log("Save result:", result);
            hideModal();
            fetchUsersAndRender(); // Refresh table
            // Optionally show success message using mainErrorDisplay or a temporary toast
        } catch (error) {
            modalErrorDisplay.textContent = error.message || 'فشل حفظ بيانات المستخدم.';
        } finally {
            saveUserBtn.disabled = false;
            saveUserBtn.textContent = isEditMode ? 'حفظ التعديلات' : 'إضافة مستخدم';
        }
    }

    function handleEditClick(event) {
        const username = event.target.closest('button').dataset.username;
        const userToEdit = currentUsers.find(u => u.username === username);
        if (userToEdit) {
            showModal('edit', userToEdit);
        } else {
            console.error(`User data not found for username: ${username}`);
            mainErrorDisplay.textContent = 'خطأ: لم يتم العثور على بيانات المستخدم للتعديل.';
        }
    }

    async function handleDeleteClick(event) {
        const username = event.target.closest('button').dataset.username;
        // Simple confirmation
        if (!confirm(`هل أنت متأكد من حذف المستخدم '${username}'؟ لا يمكن التراجع عن هذا الإجراء.`)) {
            return;
        }

        mainErrorDisplay.textContent = ''; // Clear previous errors
        const deleteButton = event.target.closest('button');
        deleteButton.disabled = true;
        deleteButton.textContent = '...'; // Indicate loading

        try {
            const endpoint = `/api/users/${encodeURIComponent(username)}`;
            const result = await apiRequest(endpoint, 'DELETE');
            console.log("Delete result:", result);
            fetchUsersAndRender(); // Refresh table
             // Optionally show success message
        } catch (error) {
            mainErrorDisplay.textContent = `فشل حذف المستخدم: ${error.message}`;
            deleteButton.disabled = false; // Re-enable on error
             deleteButton.innerHTML = '🗑️'; // Restore icon
        }
        // No finally needed as refresh handles the row removal
    }

    // --- Attach Event Listeners ---
    function attachActionListeners() {
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', handleEditClick);
        });
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', handleDeleteClick);
        });
    }

    addUserBtn.addEventListener('click', () => showModal('add'));
    closeModalBtn.addEventListener('click', hideModal);
    cancelModalBtn.addEventListener('click', hideModal);
    userForm.addEventListener('submit', handleSaveUser);

    // Close modal if clicked outside the content
    userModal.addEventListener('click', (event) => {
        if (event.target === userModal) {
            hideModal();
        }
    });

    // --- Initial Load ---
    fetchUsersAndRender();

}); // End DOMContentLoaded