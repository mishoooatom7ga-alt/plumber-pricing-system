// config/config.js
require("dotenv").config();
const path = require("path");

const ROOT = path.resolve(__dirname, "..");

module.exports = {
  PORT: Number(process.env.PORT || 3000),

  // ضع هنا SPREADSHEET_ID الصحيح (انسخ من رابط الشيت بين /d/ و /edit)
  SPREADSHEET_ID: process.env.SPREADSHEET_ID,

  // ملف مفاتيح حساب الخدمة (تأكد أنه موجود في جذر المشروع)
  GOOGLE_KEYFILE: process.env.GOOGLE_KEYFILE,

  // الكاش (بالساعات)
  CACHE_HOURS: Number(process.env.CACHE_HOURS || 6),
  CACHE_DIR: path.join(ROOT, "cache"),
  CACHE_FILE: path.join(ROOT, "cache", "products.json"),

  // ملفات السجلات (logs)
  LOG_FILE: path.join(ROOT, "logs", "server.log"),
  ERR_LOG_FILE: path.join(ROOT, "logs", "errors.log"),

  // بريد التنبيه (اختياري)
  ALERT_EMAIL_USER: process.env.ALERT_EMAIL_USER || "",
  ALERT_EMAIL_PASS: process.env.ALERT_EMAIL_PASS || "",
  ALERT_EMAIL_TO: process.env.ALERT_EMAIL_TO || "",

  // ==================================================
  // 🔽🔽 (تم إصلاح الخطأ الإملائي هنا) 🔽🔽
  // ==================================================
  // (احصل عليها من BotFather)
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN, // كان اسمها TELEGRAM_BOT_TOKEN
  // (احصل عليه عن طريق إرسال رسالة للبوت والتحقق من /getUpdates)
  TELEGRAM_CHAT_ID: process.env.TELEGRAM_CHAT_ID,
};